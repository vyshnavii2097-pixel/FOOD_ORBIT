/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        forest: {
          DEFAULT: '#174D38',
          50: '#E8F0EC',
          100: '#DCE8D8',
          200: '#B8D0AE',
          300: '#8AB488',
          400: '#5C9258',
          500: '#3A7346',
          600: '#174D38',
          700: '#103F2D',
          800: '#0A2E20',
          900: '#051A13',
        },
        midnight: '#102F27',
        ivory: '#FAF8F1',
        sage: '#DCE8D8',
        citrus: {
          DEFAULT: '#E8F17A',
          light: '#F0F5B8',
          dark: '#D4E040',
        },
        coral: {
          DEFAULT: '#F18B72',
          light: '#F8B5A3',
          dark: '#D86A50',
        },
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
      },
      animation: {
        'orbit-slow': 'orbit 40s linear infinite',
        'orbit-medium': 'orbit 25s linear infinite',
        'orbit-fast': 'orbit 15s linear infinite',
        'orbit-reverse-slow': 'orbit-reverse 50s linear infinite',
        'orbit-reverse-medium': 'orbit-reverse 30s linear infinite',
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'fade-up': 'fade-up 0.6s ease-out forwards',
        'fade-in': 'fade-in 0.5s ease-out forwards',
        'scale-in': 'scale-in 0.4s ease-out forwards',
        'slide-right': 'slide-right 0.5s ease-out forwards',
        'count-up': 'fade-in 0.8s ease-out forwards',
        'shimmer': 'shimmer 2.5s linear infinite',
        'spin-slow': 'spin 20s linear infinite',
        'dash': 'dash 3s ease-in-out infinite',
      },
      keyframes: {
        orbit: {
          '0%': { transform: 'rotate(0deg) translateX(var(--orbit-radius)) rotate(0deg)' },
          '100%': { transform: 'rotate(360deg) translateX(var(--orbit-radius)) rotate(-360deg)' },
        },
        'orbit-reverse': {
          '0%': { transform: 'rotate(360deg) translateX(var(--orbit-radius)) rotate(-360deg)' },
          '100%': { transform: 'rotate(0deg) translateX(var(--orbit-radius)) rotate(0deg)' },
        },
        'pulse-glow': {
          '0%, 100%': { opacity: '0.4', transform: 'scale(1)' },
          '50%': { opacity: '0.8', transform: 'scale(1.05)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.9)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'slide-right': {
          '0%': { opacity: '0', transform: 'translateX(-24px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        dash: {
          '0%, 100%': { strokeDashoffset: '0' },
          '50%': { strokeDashoffset: '50' },
        },
      },
      boxShadow: {
        'soft': '0 2px 12px rgba(23, 77, 56, 0.08)',
        'card': '0 4px 24px rgba(23, 77, 56, 0.10)',
        'glow': '0 0 40px rgba(232, 241, 122, 0.3)',
        'coral': '0 0 30px rgba(241, 139, 114, 0.35)',
      },
    },
  },
  plugins: [],
};
