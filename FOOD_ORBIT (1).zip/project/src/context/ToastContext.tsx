import { createContext, useContext, useState, type ReactNode } from 'react';
import { CheckCircle2, AlertCircle, X, Info } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info';

interface Toast {
  id: number;
  type: ToastType;
  message: string;
}

interface ToastContextValue {
  toast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const toastConfig: Record<ToastType, { icon: typeof CheckCircle2; color: string; bg: string; border: string }> = {
  success: { icon: CheckCircle2, color: 'text-forest-600', bg: 'bg-white', border: 'border-forest-100' },
  error: { icon: AlertCircle, color: 'text-coral-dark', bg: 'bg-white', border: 'border-coral/30' },
  info: { icon: Info, color: 'text-forest-500', bg: 'bg-white', border: 'border-forest-50' },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = (message: string, type: ToastType = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismiss = (id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-6 right-6 z-[100] flex flex-col gap-3 max-w-sm w-full pointer-events-none">
        {toasts.map((t) => {
          const cfg = toastConfig[t.type];
          return (
            <div
              key={t.id}
              className={`flex items-start gap-3 ${cfg.bg} ${cfg.border} border rounded-2xl shadow-card p-4 animate-fade-up pointer-events-auto`}
            >
              <cfg.icon className={`w-5 h-5 ${cfg.color} flex-shrink-0 mt-0.5`} />
              <p className="text-sm text-forest-600 leading-snug flex-1">{t.message}</p>
              <button onClick={() => dismiss(t.id)} className="text-forest-300 hover:text-forest-500 transition-colors flex-shrink-0">
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
