import {
  Utensils, Leaf, TrendingUp, Users, Store, HeartHandshake, MapPin,
  Award, ArrowRight, BarChart3, Globe, Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { useInView, useCountUp } from '@/hooks/useInView';
import { impactStats } from '@/data/mockData';
import type { Page } from '@/components/Navbar';

const iconMap: Record<string, typeof Utensils> = {
  utensils: Utensils,
  leaf: Leaf,
  store: Store,
  users: Users,
  'heart': HeartHandshake,
  'map-pin': MapPin,
};

const monthlyData = [
  { month: 'Apr', meals: 8200, co2: 3.1 },
  { month: 'May', meals: 10500, co2: 3.9 },
  { month: 'Jun', meals: 12800, co2: 4.7 },
  { month: 'Jul', meals: 15200, co2: 5.6 },
  { month: 'Aug', meals: 18900, co2: 7.0 },
  { month: 'Sep', meals: 19120, co2: 7.1 },
];

const categoryBreakdown = [
  { label: 'Prepared Food', percent: 38, color: 'bg-coral' },
  { label: 'Fresh Produce', percent: 24, color: 'bg-forest-400' },
  { label: 'Bakery', percent: 18, color: 'bg-amber-400' },
  { label: 'Dairy', percent: 10, color: 'bg-blue-400' },
  { label: 'Frozen', percent: 6, color: 'bg-cyan-400' },
  { label: 'Pantry', percent: 4, color: 'bg-sage' },
];

const cityImpact = [
  { city: 'Bangalore', meals: 38400, donors: 89, share: 45 },
  { city: 'Mumbai', meals: 18200, donors: 52, share: 21 },
  { city: 'Delhi', meals: 12600, donors: 38, share: 15 },
  { city: 'Chennai', meals: 8400, donors: 31, share: 10 },
  { city: 'Pune', meals: 4800, donors: 22, share: 6 },
  { city: 'Hyderabad', meals: 2320, donors: 15, share: 3 },
];

const achievements = [
  { icon: Award, title: 'Top Donor', desc: 'The Grand Hotel — 4,200 meals rescued', color: 'text-citrus-dark', bg: 'bg-citrus/10' },
  { icon: Sparkles, title: 'Fastest Rescue', desc: '12 minutes — Spice Garden → Hope Kitchen', color: 'text-coral-dark', bg: 'bg-coral/10' },
  { icon: TrendingUp, title: 'Best Month', desc: 'September 2026 — 19,120 meals', color: 'text-forest-500', bg: 'bg-forest-50' },
  { icon: Users, title: 'Largest Network', desc: 'Bangalore — 89 donors, 67 volunteers', color: 'text-forest-600', bg: 'bg-sage' },
];

function BigStatCard({ stat, index }: { stat: typeof impactStats[0]; index: number }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const value = useCountUp(stat.value, 1800, inView, stat.suffix === 't' ? 1 : 0);
  const Icon = iconMap[stat.icon] || Utensils;

  return (
    <div
      ref={ref}
      className={`bg-white rounded-2xl p-6 shadow-soft border border-forest-50 hover:shadow-card transition-all ${inView ? 'animate-fade-up' : 'opacity-0'}`}
      style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
    >
      <div className={`w-12 h-12 rounded-xl bg-forest-50 flex items-center justify-center mb-4`}>
        <Icon className="w-5 h-5 text-forest-600" strokeWidth={1.5} />
      </div>
      <div className="text-4xl font-bold text-forest-600">
        {value.toLocaleString()}{stat.suffix}
      </div>
      <div className="text-sm text-forest-400 mt-1">{stat.label}</div>
    </div>
  );
}

function MonthlyChart() {
  const { ref, inView } = useInView<HTMLDivElement>();
  const maxMeals = Math.max(...monthlyData.map((d) => d.meals));

  return (
    <div ref={ref} className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50 lg:col-span-2">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold text-forest-600 text-lg flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-forest-400" /> Meals Rescued Over Time
          </h3>
          <p className="text-xs text-forest-400 mt-0.5">Last 6 months</p>
        </div>
        <Badge color="text-forest-500" bg="bg-forest-50" dot="bg-forest-500">Growing</Badge>
      </div>
      <div className="flex items-end justify-between gap-4 h-56">
        {monthlyData.map((d, i) => {
          const heightPct = (d.meals / maxMeals) * 100;
          return (
            <div key={d.month} className="flex-1 flex flex-col items-center gap-2 group">
              <div className="text-xs font-semibold text-forest-400 opacity-0 group-hover:opacity-100 transition-opacity">
                {d.meals.toLocaleString()}
              </div>
              <div className="w-full bg-forest-50/50 rounded-xl overflow-hidden flex items-end" style={{ height: '180px' }}>
                <div
                  className={`w-full rounded-xl transition-all duration-700 ${i === monthlyData.length - 1 ? 'bg-citrus' : 'bg-forest-400 group-hover:bg-forest-500'}`}
                  style={{
                    height: inView ? `${heightPct}%` : '0%',
                    transitionDelay: `${i * 100}ms`,
                  }}
                />
              </div>
              <span className="text-xs text-forest-400 font-medium">{d.month}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CategoryBreakdown() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <div ref={ref} className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50">
      <h3 className="font-semibold text-forest-600 text-lg mb-1">Food Categories</h3>
      <p className="text-xs text-forest-400 mb-6">Distribution of rescued food</p>

      {/* Donut representation with stacked bar */}
      <div className="flex h-4 rounded-full overflow-hidden mb-6">
        {categoryBreakdown.map((cat, i) => (
          <div
            key={cat.label}
            className={`${cat.color} transition-all duration-700`}
            style={{ width: inView ? `${cat.percent}%` : '0%', transitionDelay: `${i * 80}ms` }}
          />
        ))}
      </div>

      <div className="space-y-3">
        {categoryBreakdown.map((cat) => (
          <div key={cat.label} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${cat.color}`} />
              <span className="text-sm text-forest-500">{cat.label}</span>
            </div>
            <span className="text-sm font-semibold text-forest-600">{cat.percent}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CityImpact() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <div ref={ref} className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50 lg:col-span-2">
      <div className="flex items-center gap-2 mb-6">
        <Globe className="w-5 h-5 text-forest-400" />
        <h3 className="font-semibold text-forest-600 text-lg">Impact by City</h3>
      </div>
      <div className="space-y-4">
        {cityImpact.map((city, i) => (
          <div key={city.city} className="flex items-center gap-4">
            <div className="flex items-center gap-2 w-28 flex-shrink-0">
              <MapPin className="w-4 h-4 text-forest-400" />
              <span className="text-sm font-semibold text-forest-600">{city.city}</span>
            </div>
            <div className="flex-1 h-8 bg-forest-50 rounded-lg overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-forest-500 to-forest-400 rounded-lg flex items-center justify-end px-3 transition-all duration-700"
                style={{
                  width: inView ? `${city.share * 2}%` : '0%',
                  transitionDelay: `${i * 100}ms`,
                }}
              >
                <span className="text-xs font-bold text-ivory">{city.meals.toLocaleString()}</span>
              </div>
            </div>
            <span className="text-xs text-forest-400 w-20 text-right flex-shrink-0">{city.donors} donors</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Co2Savings() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <div ref={ref} className="bg-forest-600 rounded-2xl p-6 text-ivory relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-citrus/10 rounded-full blur-2xl" />
      <div className="relative">
        <div className="flex items-center gap-2 mb-4">
          <Leaf className="w-5 h-5 text-citrus" />
          <h3 className="font-semibold text-lg">CO₂ Diverted</h3>
        </div>
        <div className="text-5xl font-bold text-citrus mb-2">
          {inView ? '31.4' : '0'}<span className="text-2xl">t</span>
        </div>
        <p className="text-sage/70 text-sm mb-4">Equivalent to taking 6.8 cars off the road for a year</p>
        <div className="space-y-2">
          {[
            { label: 'Trees planted equivalent', value: '514 trees' },
            { label: 'Water saved', value: '12,600 L' },
            { label: 'Landfill space saved', value: '78 m³' },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between text-sm">
              <span className="text-sage/60">{item.label}</span>
              <span className="font-semibold text-citrus">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AchievementsSection() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section ref={ref} className="mt-12">
      <SectionHeading
        center
        eyebrow="Milestones"
        title={<>Achievements that <span className="italic text-coral">inspire</span></>}
      />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
        {achievements.map((a, i) => (
          <div
            key={a.title}
            className={`bg-white rounded-2xl p-6 shadow-soft border border-forest-50 hover:shadow-card transition-all ${inView ? 'animate-scale-in' : 'opacity-0'}`}
            style={{ animationDelay: `${i * 120}ms`, animationFillMode: 'forwards' }}
          >
            <div className={`w-12 h-12 rounded-xl ${a.bg} flex items-center justify-center mb-4`}>
              <a.icon className={`w-5 h-5 ${a.color}`} strokeWidth={1.5} />
            </div>
            <h4 className="font-semibold text-forest-600 text-sm mb-1">{a.title}</h4>
            <p className="text-xs text-forest-400">{a.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ImpactPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <div className="min-h-screen pt-24 pb-12 bg-sage/20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <h1 className="font-serif text-4xl text-forest-600">Impact Analytics</h1>
          <p className="text-forest-400 mt-2">Tracking our collective contribution to a zero-waste future.</p>
        </div>

        {/* Big stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {impactStats.map((stat, i) => (
            <BigStatCard key={stat.label} stat={stat} index={i} />
          ))}
        </div>

        {/* Charts grid */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <MonthlyChart />
          <CategoryBreakdown />
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <CityImpact />
          <Co2Savings />
        </div>

        {/* Achievements */}
        <AchievementsSection />

        {/* Download report CTA */}
        <div className="mt-12 bg-white rounded-2xl p-8 shadow-soft border border-forest-50 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-serif text-2xl text-forest-600 mb-2">Download your impact report</h3>
            <p className="text-forest-400 text-sm">Get a detailed PDF of your food rescue contributions for your records or tax documentation.</p>
          </div>
          <Button size="lg" onClick={() => onNavigate('dashboard')}>
            Generate Report <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
