import { type ReactNode } from 'react';

interface BadgeProps {
  children: ReactNode;
  color?: string;
  bg?: string;
  dot?: string;
  className?: string;
}

export function Badge({ children, color = 'text-forest-600', bg = 'bg-forest-50', dot, className = '' }: BadgeProps) {
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${color} ${bg} ${className}`}>
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dot} animate-pulse`} />}
      {children}
    </span>
  );
}
