import { useState, useEffect } from 'react';
import { Navbar, type Page } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { LandingPage } from '@/pages/LandingPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { ListingsPage } from '@/pages/ListingsPage';
import { NetworkPage } from '@/pages/NetworkPage';
import { ImpactPage } from '@/pages/ImpactPage';

function App() {
  const [page, setPage] = useState<Page>('home');

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [page]);

  const renderPage = () => {
    switch (page) {
      case 'home':
        return <LandingPage onNavigate={setPage} />;
      case 'dashboard':
        return <DashboardPage onNavigate={setPage} />;
      case 'listings':
        return <ListingsPage />;
      case 'network':
        return <NetworkPage onNavigate={setPage} />;
      case 'impact':
        return <ImpactPage onNavigate={setPage} />;
      default:
        return <LandingPage onNavigate={setPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-ivory">
      <Navbar currentPage={page} onNavigate={setPage} />
      <main>{renderPage()}</main>
      <Footer onNavigate={setPage} />
    </div>
  );
}

export default App;
