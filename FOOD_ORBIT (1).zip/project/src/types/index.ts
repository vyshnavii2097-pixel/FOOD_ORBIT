export type UserRole = 'donor' | 'ngo' | 'volunteer';

export type DonationStatus =
  | 'listed'
  | 'claimed'
  | 'pickup_scheduled'
  | 'ready_for_collection'
  | 'picked_up'
  | 'handover_completed'
  | 'cancelled'
  | 'expired';

export type ClaimStatus =
  | 'active'
  | 'pickup_scheduled'
  | 'ready'
  | 'picked_up'
  | 'completed'
  | 'cancelled'
  | 'failed';

export type FoodCategory = 'prepared' | 'produce' | 'bakery' | 'dairy' | 'frozen' | 'pantry';

export type Urgency = 'normal' | 'high' | 'critical';

export interface Profile {
  id: string;
  role: UserRole;
  display_name: string;
  organization_name: string | null;
  phone: string | null;
  city: string | null;
  bio: string | null;
  created_at: string;
}

export interface PickupAddress {
  id: string;
  user_id: string;
  label: string;
  full_address: string;
  locality: string;
  city: string;
  state: string;
  pin_code: string;
  latitude: number | null;
  longitude: number | null;
  pickup_instructions: string;
  created_at: string;
}

export interface Donation {
  id: string;
  donor_id: string;
  title: string;
  description: string;
  category: FoodCategory;
  quantity: number;
  unit: string;
  servings: number;
  available_quantity: number;
  status: DonationStatus;
  image_url: string;
  temperature: string;
  dietary: string[];
  allergens: string;
  storage_instructions: string;
  preparation_time: string | null;
  expiry_time: string;
  pickup_address_id: string | null;
  pickup_date: string | null;
  pickup_time_slot: string;
  pickup_deadline: string | null;
  pickup_instructions: string;
  confirmation_code: string | null;
  safety_verified: boolean;
  created_at: string;
  updated_at: string;
  donor_profile?: Profile;
  pickup_address?: PickupAddress;
}

export interface Claim {
  id: string;
  donation_id: string;
  ngo_id: string;
  allocated_quantity: number;
  status: ClaimStatus;
  scheduled_pickup_at: string | null;
  pickup_notes: string;
  verified_at: string | null;
  created_at: string;
  updated_at: string;
  ngo_profile?: Profile;
  donation?: Donation;
}

export interface StatusHistoryEntry {
  id: string;
  donation_id: string;
  status: DonationStatus;
  changed_by: string;
  notes: string;
  created_at: string;
  changed_by_profile?: Profile;
}

export interface FoodRequest {
  id: string;
  ngo_id: string;
  category: FoodCategory;
  quantity_needed: number;
  unit: string;
  servings_needed: number;
  urgency: Urgency;
  description: string;
  status: 'open' | 'fulfilled' | 'closed';
  city: string;
  created_at: string;
  updated_at: string;
  ngo_profile?: Profile;
}

export const donationStatusConfig: Record<DonationStatus, { label: string; step: number; color: string; bg: string }> = {
  listed: { label: 'Listed', step: 0, color: 'text-forest-600', bg: 'bg-forest-100' },
  claimed: { label: 'Claimed', step: 1, color: 'text-amber-700', bg: 'bg-amber-100' },
  pickup_scheduled: { label: 'Pickup Scheduled', step: 2, color: 'text-blue-700', bg: 'bg-blue-100' },
  ready_for_collection: { label: 'Ready for Collection', step: 3, color: 'text-citrus-dark', bg: 'bg-citrus/20' },
  picked_up: { label: 'Picked Up', step: 4, color: 'text-forest-600', bg: 'bg-forest-100' },
  handover_completed: { label: 'Handover Completed', step: 5, color: 'text-forest-600', bg: 'bg-forest-600' },
  cancelled: { label: 'Cancelled', step: -1, color: 'text-red-600', bg: 'bg-red-100' },
  expired: { label: 'Expired', step: -1, color: 'text-red-600', bg: 'bg-red-100' },
};

export const donationTimelineSteps: DonationStatus[] = [
  'listed',
  'claimed',
  'pickup_scheduled',
  'ready_for_collection',
  'picked_up',
  'handover_completed',
];

export const claimStatusConfig: Record<ClaimStatus, { label: string; color: string; bg: string }> = {
  active: { label: 'Active', color: 'text-amber-700', bg: 'bg-amber-100' },
  pickup_scheduled: { label: 'Pickup Scheduled', color: 'text-blue-700', bg: 'bg-blue-100' },
  ready: { label: 'Ready for Collection', color: 'text-citrus-dark', bg: 'bg-citrus/20' },
  picked_up: { label: 'Picked Up', color: 'text-forest-600', bg: 'bg-forest-100' },
  completed: { label: 'Completed', color: 'text-forest-600', bg: 'bg-forest-600' },
  cancelled: { label: 'Cancelled', color: 'text-red-600', bg: 'bg-red-100' },
  failed: { label: 'Pickup Failed', color: 'text-coral-dark', bg: 'bg-coral/15' },
};

export const categoryConfig: Record<FoodCategory, { label: string; color: string; bg: string }> = {
  prepared: { label: 'Prepared Food', color: 'text-coral-dark', bg: 'bg-coral/15' },
  produce: { label: 'Fresh Produce', color: 'text-forest-500', bg: 'bg-forest-100' },
  bakery: { label: 'Bakery', color: 'text-amber-700', bg: 'bg-amber-100' },
  dairy: { label: 'Dairy', color: 'text-blue-700', bg: 'bg-blue-100' },
  frozen: { label: 'Frozen', color: 'text-cyan-700', bg: 'bg-cyan-100' },
  pantry: { label: 'Pantry', color: 'text-forest-600', bg: 'bg-sage' },
};

export const urgencyConfig: Record<Urgency, { label: string; color: string; bg: string }> = {
  normal: { label: 'Normal', color: 'text-forest-600', bg: 'bg-forest-50' },
  high: { label: 'High', color: 'text-amber-700', bg: 'bg-amber-100' },
  critical: { label: 'Critical', color: 'text-coral-dark', bg: 'bg-coral/15' },
};
