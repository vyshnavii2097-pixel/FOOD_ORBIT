import { type ButtonHTMLAttributes, type ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'coral';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
}

const variantStyles: Record<Variant, string> = {
  primary: 'bg-forest-600 text-ivory hover:bg-forest-700 shadow-soft hover:shadow-card transition-all',
  secondary: 'bg-citrus text-forest-600 hover:bg-citrus-dark font-semibold transition-all',
  outline: 'border-2 border-forest-600 text-forest-600 hover:bg-forest-600 hover:text-ivory transition-all',
  ghost: 'text-forest-600 hover:bg-forest-50 transition-colors',
  coral: 'bg-coral text-white hover:bg-coral-dark shadow-coral transition-all',
};

const sizeStyles: Record<Size, string> = {
  sm: 'px-4 py-2 text-sm rounded-lg',
  md: 'px-6 py-3 text-sm rounded-xl',
  lg: 'px-8 py-4 text-base rounded-xl',
};

export function Button({ variant = 'primary', size = 'md', children, className = '', ...props }: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 font-semibold transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
