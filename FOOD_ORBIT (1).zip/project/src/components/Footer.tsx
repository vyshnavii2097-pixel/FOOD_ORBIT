import { Leaf, Github, Twitter, Linkedin, Instagram, Mail, MapPin, Phone } from 'lucide-react';
import type { Page } from './Navbar';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const handleNav = (page: Page) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-midnight text-ivory pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-10 h-10 rounded-xl bg-forest-600 flex items-center justify-center">
                <Leaf className="w-5 h-5 text-citrus" strokeWidth={2} />
              </div>
              <span className="font-bold text-lg tracking-tight">FOOD ORBIT</span>
            </div>
            <p className="text-sage/70 text-sm leading-relaxed mb-6">
              Connecting surplus food to those who need it most. Every meal rescued is a win for people and the planet.
            </p>
            <div className="flex gap-3">
              {[Twitter, Instagram, Linkedin, Github].map((Icon, i) => (
                <a key={i} href="#" className="w-9 h-9 rounded-lg bg-forest-700/50 flex items-center justify-center hover:bg-forest-600 transition-colors">
                  <Icon className="w-4 h-4 text-sage" />
                </a>
              ))}
            </div>
          </div>

          {/* Platform */}
          <div>
            <h4 className="font-semibold text-citrus mb-4 text-sm uppercase tracking-wider">Platform</h4>
            <div className="flex flex-col gap-3">
              {[
                { label: 'Dashboard', page: 'dashboard' as Page },
                { label: 'Surplus Listings', page: 'listings' as Page },
                { label: 'NGO Network', page: 'network' as Page },
                { label: 'Impact Analytics', page: 'impact' as Page },
              ].map((link) => (
                <button key={link.label} onClick={() => handleNav(link.page)} className="text-sage/70 text-sm hover:text-citrus transition-colors text-left">
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold text-citrus mb-4 text-sm uppercase tracking-wider">Resources</h4>
            <div className="flex flex-col gap-3">
              {['Food Safety Guide', 'Volunteer Handbook', 'Donor Best Practices', 'API Documentation', 'Press Kit'].map((label) => (
                <a key={label} href="#" className="text-sage/70 text-sm hover:text-citrus transition-colors">{label}</a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-citrus mb-4 text-sm uppercase tracking-wider">Get in Touch</h4>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sage/70 text-sm">
                <Mail className="w-4 h-4 text-citrus flex-shrink-0" />
                hello@foodorbit.org
              </div>
              <div className="flex items-center gap-2 text-sage/70 text-sm">
                <Phone className="w-4 h-4 text-citrus flex-shrink-0" />
                +91 80 4567 8900
              </div>
              <div className="flex items-center gap-2 text-sage/70 text-sm">
                <MapPin className="w-4 h-4 text-citrus flex-shrink-0" />
                Bangalore, India
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-forest-700/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sage/50 text-sm">© 2026 FOOD ORBIT. Every Surplus Has a Purpose.</p>
          <div className="flex gap-6">
            <a href="#" className="text-sage/50 text-sm hover:text-citrus transition-colors">Privacy Policy</a>
            <a href="#" className="text-sage/50 text-sm hover:text-citrus transition-colors">Terms of Service</a>
            <a href="#" className="text-sage/50 text-sm hover:text-citrus transition-colors">Food Safety</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
