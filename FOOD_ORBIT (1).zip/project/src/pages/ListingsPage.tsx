import { useState, useMemo } from 'react';
import {
  Search, SlidersHorizontal, Clock, MapPin, Users, Thermometer,
  Heart, Navigation, AlertTriangle, X, Plus, Package,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { surplusListings, categoryConfig, statusConfig } from '@/data/mockData';
import type { FoodCategory, ListingStatus, SurplusListing } from '@/types';

const allCategories: { id: FoodCategory | 'all'; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'prepared', label: 'Prepared' },
  { id: 'produce', label: 'Produce' },
  { id: 'bakery', label: 'Bakery' },
  { id: 'dairy', label: 'Dairy' },
  { id: 'frozen', label: 'Frozen' },
  { id: 'pantry', label: 'Pantry' },
];

const sortOptions = [
  { id: 'urgent', label: 'Most Urgent' },
  { id: 'nearest', label: 'Nearest First' },
  { id: 'recent', label: 'Most Recent' },
  { id: 'servings', label: 'Most Servings' },
];

function ListingCard({ listing, onClaim }: { listing: SurplusListing; onClaim: (id: string) => void }) {
  const cat = categoryConfig[listing.category];
  const status = statusConfig[listing.status];
  const urgent = listing.expiresInMin <= 60;

  return (
    <div className={`bg-white rounded-2xl shadow-soft border border-forest-50 overflow-hidden hover:shadow-card transition-all duration-300 group ${urgent ? 'ring-1 ring-coral/30' : ''}`}>
      <div className="relative h-48 overflow-hidden">
        <img
          src={listing.imageUrl}
          alt={listing.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        {urgent && (
          <div className="absolute top-3 left-3">
            <Badge color="text-white" bg="bg-coral" dot="bg-white" className="shadow-coral">
              <AlertTriangle className="w-3 h-3" /> Urgent
            </Badge>
          </div>
        )}
        <div className="absolute top-3 right-3">
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${status.color} ${status.bg} backdrop-blur-sm`}>
            <span className={`inline-block w-1.5 h-1.5 rounded-full ${status.dot} mr-1.5 ${listing.status === 'available' ? 'animate-pulse' : ''}`} />
            {status.label}
          </span>
        </div>
        <div className="absolute bottom-3 left-3">
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${cat.color} ${cat.bg} backdrop-blur-sm`}>
            {cat.label}
          </span>
        </div>
      </div>

      <div className="p-5">
        <h3 className="font-semibold text-forest-600 text-lg mb-1">{listing.title}</h3>
        <p className="text-xs text-forest-400 mb-3">{listing.donorName} · {listing.donorType}</p>
        <p className="text-sm text-forest-400 leading-relaxed mb-4 line-clamp-2">{listing.description}</p>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="flex items-center gap-2 text-xs text-forest-500">
            <Users className="w-3.5 h-3.5 text-forest-400" />
            <span className="font-semibold">{listing.servings}</span> servings
          </div>
          <div className="flex items-center gap-2 text-xs text-forest-500">
            <Package className="w-3.5 h-3.5 text-forest-400" />
            <span className="font-semibold">{listing.quantity}</span> {listing.unit}
          </div>
          <div className="flex items-center gap-2 text-xs text-forest-500">
            <MapPin className="w-3.5 h-3.5 text-forest-400" />
            {listing.distanceKm} km away
          </div>
          <div className={`flex items-center gap-2 text-xs ${urgent ? 'text-coral font-semibold' : 'text-forest-500'}`}>
            <Clock className="w-3.5 h-3.5" />
            {listing.expiresInMin} min left
          </div>
        </div>

        <div className="flex items-center gap-2 mb-4 text-xs text-forest-400">
          <Thermometer className="w-3.5 h-3.5" />
          {listing.temperature}
        </div>

        <div className="flex gap-2">
          {listing.status === 'available' ? (
            <>
              <Button size="sm" className="flex-1" onClick={() => onClaim(listing.id)}>
                <Heart className="w-4 h-4" /> Claim
              </Button>
              <button className="px-3 py-2 rounded-lg border-2 border-forest-100 text-forest-500 hover:border-forest-600 hover:text-forest-600 transition-colors">
                <Navigation className="w-4 h-4" />
              </button>
            </>
          ) : (
            <div className="flex-1 text-center py-2 rounded-lg bg-amber-50 text-amber-700 text-sm font-semibold">
              Claimed by an NGO partner
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function NewListingModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 animate-fade-in">
      <div className="absolute inset-0 bg-midnight/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-ivory rounded-3xl p-8 max-w-lg w-full shadow-card animate-scale-in max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-lg hover:bg-forest-50 transition-colors">
          <X className="w-5 h-5 text-forest-400" />
        </button>
        <h2 className="font-serif text-3xl text-forest-600 mb-2">Post Surplus Food</h2>
        <p className="text-sm text-forest-400 mb-6">Share your surplus with the network in under a minute.</p>

        <div className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Food Title</label>
            <input
              type="text"
              placeholder="e.g. Trays of Vegetable Biryani"
              className="w-full px-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Quantity</label>
              <input
                type="number"
                placeholder="8"
                className="w-full px-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Unit</label>
              <input
                type="text"
                placeholder="trays"
                className="w-full px-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
              />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Category</label>
            <div className="flex flex-wrap gap-2">
              {allCategories.filter((c) => c.id !== 'all').map((cat) => (
                <button
                  key={cat.id}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold border border-forest-100 text-forest-500 hover:border-forest-400 hover:bg-forest-50 transition-colors"
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Pickup Location</label>
            <input
              type="text"
              placeholder="Koramangala, Bangalore"
              className="w-full px-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Estimated Servings</label>
            <input
              type="number"
              placeholder="120"
              className="w-full px-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <Button variant="ghost" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button variant="primary" className="flex-1" onClick={onClose}>Post Listing</Button>
        </div>
      </div>
    </div>
  );
}

export function ListingsPage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<FoodCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<ListingStatus | 'all'>('available');
  const [sortBy, setSortBy] = useState('urgent');
  const [showNewModal, setShowNewModal] = useState(false);
  const [claimedListings, setClaimedListings] = useState<Set<string>>(new Set());

  const filtered = useMemo(() => {
    let result = surplusListings.filter((l) => {
      const matchesSearch = l.title.toLowerCase().includes(search.toLowerCase()) ||
        l.donorName.toLowerCase().includes(search.toLowerCase()) ||
        l.location.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === 'all' || l.category === category;
      const effectiveStatus = claimedListings.has(l.id) ? 'claimed' : l.status;
      const matchesStatus = statusFilter === 'all' || effectiveStatus === statusFilter;
      return matchesSearch && matchesCategory && matchesStatus;
    });

    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'urgent': return a.expiresInMin - b.expiresInMin;
        case 'nearest': return a.distanceKm - b.distanceKm;
        case 'recent': return a.postedAt.localeCompare(b.postedAt);
        case 'servings': return b.servings - a.servings;
        default: return 0;
      }
    });

    return result;
  }, [search, category, statusFilter, sortBy, claimedListings]);

  const handleClaim = (id: string) => {
    setClaimedListings((prev) => new Set([...prev, id]));
  };

  const availableCount = surplusListings.filter((l) => l.status === 'available' && !claimedListings.has(l.id)).length;
  const urgentCount = surplusListings.filter((l) => l.status === 'available' && l.expiresInMin <= 60 && !claimedListings.has(l.id)).length;

  return (
    <div className="min-h-screen pt-24 pb-12 bg-sage/20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="font-serif text-4xl text-forest-600">Surplus Listings</h1>
              <p className="text-forest-400 mt-2">Available food from donors across the network.</p>
            </div>
            <Button onClick={() => setShowNewModal(true)}>
              <Plus className="w-4 h-4" /> Post Surplus
            </Button>
          </div>
          <div className="flex flex-wrap gap-3 mt-4">
            <Badge color="text-forest-600" bg="bg-forest-50" dot="bg-forest-500">
              {availableCount} available
            </Badge>
            {urgentCount > 0 && (
              <Badge color="text-coral-dark" bg="bg-coral/15" dot="bg-coral">
                {urgentCount} urgent rescue needed
              </Badge>
            )}
          </div>
        </div>

        {/* Filters bar */}
        <div className="bg-white rounded-2xl p-4 shadow-soft border border-forest-50 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-forest-300" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by food, donor, or location..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-forest-50/50 text-sm text-forest-600 placeholder:text-forest-300 focus:outline-none focus:bg-white focus:ring-2 focus:ring-forest-200 transition-all"
              />
            </div>

            {/* Sort */}
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-forest-400 flex-shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-3 py-2.5 rounded-xl bg-forest-50/50 text-sm text-forest-600 font-semibold focus:outline-none focus:bg-white focus:ring-2 focus:ring-forest-200 transition-all cursor-pointer"
              >
                {sortOptions.map((opt) => (
                  <option key={opt.id} value={opt.id}>{opt.label}</option>
                ))}
              </select>
            </div>

            {/* Status filter */}
            <div className="flex items-center gap-1 bg-forest-50/50 rounded-xl p-1">
              {[
                { id: 'available' as const, label: 'Available' },
                { id: 'claimed' as const, label: 'Claimed' },
                { id: 'all' as const, label: 'All' },
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStatusFilter(s.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    statusFilter === s.id ? 'bg-forest-600 text-ivory shadow-soft' : 'text-forest-400 hover:bg-forest-100'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Category chips */}
          <div className="flex flex-wrap gap-2 mt-4">
            {allCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  category === cat.id
                    ? 'bg-forest-600 text-ivory'
                    : 'bg-forest-50 text-forest-500 hover:bg-forest-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results count */}
        <p className="text-sm text-forest-400 mb-4">
          {filtered.length} {filtered.length === 1 ? 'listing' : 'listings'} found
        </p>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((listing, i) => (
              <div
                key={listing.id}
                className="animate-fade-up opacity-0"
                style={{ animationDelay: `${i * 80}ms`, animationFillMode: 'forwards' }}
              >
                <ListingCard
                  listing={{ ...listing, status: claimedListings.has(listing.id) ? 'claimed' : listing.status }}
                  onClaim={handleClaim}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-full bg-forest-50 flex items-center justify-center mx-auto mb-4">
              <Package className="w-8 h-8 text-forest-300" />
            </div>
            <p className="text-forest-400 font-semibold">No listings match your filters</p>
            <p className="text-forest-300 text-sm mt-1">Try adjusting your search or category.</p>
          </div>
        )}
      </div>

      {showNewModal && <NewListingModal onClose={() => setShowNewModal(false)} />}
    </div>
  );
}
