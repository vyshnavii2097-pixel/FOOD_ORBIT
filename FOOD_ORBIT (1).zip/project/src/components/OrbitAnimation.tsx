import { Utensils, HeartHandshake, Bike, Leaf, Store, Users } from 'lucide-react';

interface OrbitItem {
  icon: typeof Utensils;
  label: string;
  color: string;
}

interface OrbitPath {
  radius: number;
  duration: string;
  reverse?: boolean;
  items: OrbitItem[];
}

const orbits: OrbitPath[] = [
  {
    radius: 110,
    duration: 'animate-orbit-slow',
    items: [
      { icon: Utensils, label: 'Restaurant', color: 'text-coral-dark' },
      { icon: Store, label: 'Grocery', color: 'text-coral-dark' },
      { icon: Leaf, label: 'Farm', color: 'text-forest-500' },
    ],
  },
  {
    radius: 180,
    duration: 'animate-orbit-medium',
    reverse: true,
    items: [
      { icon: HeartHandshake, label: 'NGO', color: 'text-forest-600' },
      { icon: Users, label: 'Kitchen', color: 'text-forest-500' },
    ],
  },
  {
    radius: 250,
    duration: 'animate-orbit-fast',
    items: [
      { icon: Bike, label: 'Volunteer', color: 'text-citrus-dark' },
      { icon: Leaf, label: 'Impact', color: 'text-citrus-dark' },
    ],
  },
];

export function OrbitAnimation() {
  return (
    <div className="relative w-full aspect-square max-w-[600px] mx-auto">
      {/* Outer glow */}
      <div className="absolute inset-0 rounded-full bg-forest-400/10 blur-3xl animate-pulse-glow" />

      {/* Orbital paths (SVG rings) */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 600 600" fill="none">
        <circle cx="300" cy="300" r="110" stroke="#174D38" strokeOpacity="0.12" strokeWidth="1" strokeDasharray="4 6" />
        <circle cx="300" cy="300" r="180" stroke="#174D38" strokeOpacity="0.10" strokeWidth="1" strokeDasharray="4 6" />
        <circle cx="300" cy="300" r="250" stroke="#174D38" strokeOpacity="0.08" strokeWidth="1" strokeDasharray="4 6" />
      </svg>

      {/* Center logo */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-citrus/30 blur-2xl animate-pulse-glow scale-150" />
          <div className="relative w-28 h-28 md:w-36 md:h-36 rounded-full bg-forest-600 border-4 border-citrus/40 shadow-glow flex flex-col items-center justify-center">
            <Leaf className="w-8 h-8 md:w-10 md:h-10 text-citrus mb-1" strokeWidth={1.5} />
            <span className="text-ivory font-bold text-sm md:text-base tracking-wider">FOOD</span>
            <span className="text-citrus font-bold text-sm md:text-base tracking-wider">ORBIT</span>
          </div>
        </div>
      </div>

      {/* Orbit items */}
      {orbits.map((orbit, oi) =>
        orbit.items.map((item, ii) => {
          const totalItems = orbit.items.length;
          const angle = (360 / totalItems) * ii;
          return (
            <div
              key={`orbit-${oi}-item-${ii}`}
              className="absolute top-1/2 left-1/2"
              style={{
                '--orbit-radius': `${orbit.radius}px`,
                transform: `rotate(${angle}deg)`,
              } as React.CSSProperties}
            >
              <div
                className={`${orbit.duration} ${orbit.reverse ? 'animate-orbit-reverse-slow' : ''}`}
                style={{ '--orbit-radius': `${orbit.radius}px` } as React.CSSProperties}
              >
                <div className="flex flex-col items-center gap-1 group">
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-ivory border border-forest-100 shadow-card flex items-center justify-center group-hover:scale-110 group-hover:border-citrus transition-transform duration-300">
                    <item.icon className={`w-5 h-5 md:w-6 md:h-6 ${item.color}`} strokeWidth={1.5} />
                  </div>
                </div>
              </div>
            </div>
          );
        })
      )}

      {/* Traveling dots */}
      {orbits.map((orbit, oi) => (
        <div
          key={`dots-${oi}`}
          className="absolute top-1/2 left-1/2"
          style={{ '--orbit-radius': `${orbit.radius}px` } as React.CSSProperties}
        >
          <div
            className={`${orbit.duration} ${orbit.reverse ? 'animate-orbit-reverse-slow' : ''}`}
            style={{ '--orbit-radius': `${orbit.radius}px` } as React.CSSProperties}
          >
            <div className="w-2 h-2 rounded-full bg-citrus shadow-glow" />
          </div>
        </div>
      ))}
    </div>
  );
}
