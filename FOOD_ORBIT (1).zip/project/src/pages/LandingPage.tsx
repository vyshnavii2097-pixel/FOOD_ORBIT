import { ArrowRight, Clock, MapPin, TrendingUp, Zap, ShieldCheck, Bike, AlertCircle, HeartHandshake, Sparkles, Quote, Star, Utensils, Leaf, Store, Users } from 'lucide-react';
import { OrbitAnimation } from '@/components/OrbitAnimation';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { useInView, useCountUp } from '@/hooks/useInView';
import { impactStats, timelineEvents, rescueActivities } from '@/data/mockData';
import type { Page } from '@/components/Navbar';
import { useState, useEffect } from 'react';

const iconMap: Record<string, typeof Utensils> = {
  utensils: Utensils,
  leaf: Leaf,
  store: Store,
  users: Users,
  'heart': HeartHandshake,
  'map-pin': MapPin,
};

const timelineIconMap: Record<string, typeof Utensils> = {
  'alert-circle': AlertCircle,
  zap: Zap,
  bike: Bike,
  'shield-check': ShieldCheck,
  'heart-handshake': HeartHandshake,
};

function HeroSection({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <section className="relative min-h-screen flex items-center pt-24 pb-12 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-ivory" />
      <div className="absolute top-0 right-0 w-[50%] h-full bg-gradient-to-bl from-sage/40 to-transparent" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-citrus/10 rounded-full blur-3xl" />
      <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-coral/8 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center w-full">
        {/* Left content */}
        <div className="animate-fade-up">
          <Badge color="text-forest-600" bg="bg-forest-50" dot="bg-citrus-dark" className="mb-6">
            <Sparkles className="w-3 h-3" /> Live Rescue Network
          </Badge>
          <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05] text-forest-600 text-balance mb-6">
            Every Surplus<br />
            Has a <span className="italic text-coral">Purpose</span>
          </h1>
          <p className="text-lg md:text-xl text-forest-400 leading-relaxed mb-8 max-w-lg">
            FOOD ORBIT connects restaurants, hotels, grocery stores, and event organizers with NGOs, community kitchens, and volunteers — redistributing surplus food before it becomes waste.
          </p>
          <div className="flex flex-wrap gap-4 mb-12">
            <Button size="lg" onClick={() => onNavigate('listings')}>
              Browse Surplus <ArrowRight className="w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => onNavigate('dashboard')}>
              Donor Dashboard
            </Button>
          </div>

          {/* Mini stats */}
          <div className="grid grid-cols-3 gap-6 max-w-md">
            {[
              { value: '84K+', label: 'Meals Rescued' },
              { value: '247', label: 'Active Donors' },
              { value: '31t', label: 'CO₂ Diverted' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-3xl font-bold text-forest-600">{stat.value}</div>
                <div className="text-xs text-forest-400 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Orbital Animation */}
        <div className="flex items-center justify-center animate-scale-in">
          <OrbitAnimation />
        </div>
      </div>
    </section>
  );
}

function StatsSection() {
  const { ref, inView } = useInView<HTMLDivElement>();

  return (
    <section ref={ref} className="py-20 bg-forest-600 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-64 h-64 border border-citrus rounded-full" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 border border-citrus rounded-full" />
      </div>
      <div className="relative max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {impactStats.map((stat, i) => {
            const Icon = iconMap[stat.icon] || Utensils;
            return <StatCard key={stat.label} stat={stat} icon={Icon} delay={i * 100} inView={inView} />;
          })}
        </div>
      </div>
    </section>
  );
}

function StatCard({ stat, icon: Icon, delay, inView }: { stat: typeof impactStats[0]; icon: typeof Utensils; delay: number; inView: boolean }) {
  const value = useCountUp(stat.value, 1500, inView, stat.suffix === 't' ? 1 : 0);
  return (
    <div
      className="flex flex-col items-center text-center group animate-fade-up opacity-0"
      style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards', animationPlayState: inView ? 'running' : 'paused' }}
    >
      <div className="w-12 h-12 rounded-xl bg-forest-700/60 flex items-center justify-center mb-3 group-hover:bg-citrus/20 transition-colors">
        <Icon className="w-5 h-5 text-citrus" strokeWidth={1.5} />
      </div>
      <div className="text-3xl md:text-4xl font-bold text-ivory">
        {value.toLocaleString()}{stat.suffix}
      </div>
      <div className="text-xs text-sage/60 mt-1 uppercase tracking-wider">{stat.label}</div>
    </div>
  );
}

function HowItWorksSection() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section ref={ref} className="py-24 bg-ivory">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading
          center
          eyebrow="How It Works"
          title={<>From <span className="italic text-coral">surplus</span> to <span className={"italic text-forest-500"}>sustenance</span> in five steps</>}
          subtitle={"Our intelligent matching engine bridges the gap between food surplus and food insecurity in under an hour."}
        />
        <div className="mt-16 grid md:grid-cols-3 lg:grid-cols-5 gap-6">
          {timelineEvents.map((event, i) => {
            const Icon = timelineIconMap[event.icon] || AlertCircle;
            return (
              <div
                key={event.phase}
                className={`relative ${inView ? 'animate-fade-up' : 'opacity-0'}`}
                style={{ animationDelay: `${i * 150}ms`, animationFillMode: 'forwards' }}
              >
                {/* Connecting line */}
                {i < timelineEvents.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-px bg-gradient-to-r from-forest-200 to-transparent -translate-x-8" />
                )}
                <div className="relative bg-white rounded-2xl p-6 shadow-soft border border-forest-50 hover:shadow-card hover:border-citrus/40 transition-all duration-300 group">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-14 h-14 rounded-2xl bg-forest-50 flex items-center justify-center group-hover:bg-citrus/20 transition-colors">
                      <Icon className="w-6 h-6 text-forest-600" strokeWidth={1.5} />
                    </div>
                    <span className="font-serif text-3xl text-forest-100 font-bold">{event.phase}</span>
                  </div>
                  <h3 className="font-semibold text-forest-600 text-lg mb-2">{event.title}</h3>
                  <p className="text-sm text-forest-400 leading-relaxed mb-3">{event.description}</p>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-coral">
                    <Clock className="w-3 h-3" />
                    {event.duration}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

const features = [
  {
    icon: Zap,
    title: 'Smart Match Engine',
    description: 'AI-powered matching pairs surplus food with the nearest NGO based on capacity, dietary needs, and location — in under 60 seconds.',
    color: 'text-coral',
    bg: 'bg-coral/10',
  },
  {
    icon: ShieldCheck,
    title: 'Cold-Chain Tracking',
    description: 'Real-time temperature and time tracking ensures food safety compliance from donor kitchen to community plate.',
    color: 'text-forest-500',
    bg: 'bg-forest-50',
  },
  {
    icon: Bike,
    title: 'Volunteer Dispatch',
    description: 'Vetted volunteers receive instant notifications for nearby rescue missions. One tap to accept, route-optimized delivery.',
    color: 'text-citrus-dark',
    bg: 'bg-citrus/10',
  },
  {
    icon: TrendingUp,
    title: 'Impact Analytics',
    description: 'Track meals rescued, CO₂ diverted, and community impact with beautiful, real-time dashboards and reports.',
    color: 'text-forest-600',
    bg: 'bg-sage',
  },
];

function FeaturesSection() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section ref={ref} className="py-24 bg-gradient-to-b from-ivory to-sage/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <SectionHeading
              eyebrow="Platform Features"
              title={<>Technology that makes <span className="italic text-coral">rescue effortless</span></>}
              subtitle={"Every feature is designed to remove friction from the food rescue process, from posting surplus to delivering meals."}
            />
            <div className="mt-10 space-y-6">
              {features.map((feature, i) => (
                <div
                  key={feature.title}
                  className={`flex gap-5 group ${inView ? 'animate-slide-right' : 'opacity-0'}`}
                  style={{ animationDelay: `${i * 120}ms`, animationFillMode: 'forwards' }}
                >
                  <div className={`flex-shrink-0 w-14 h-14 rounded-2xl ${feature.bg} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <feature.icon className={`w-6 h-6 ${feature.color}`} strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-forest-600 text-lg mb-1">{feature.title}</h3>
                    <p className="text-forest-400 text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Image collage */}
          <div className="relative grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <img
                src="https://images.pexels.com/photos/6591165/pexels-photo-6591165.jpeg?auto=compress&cs=tinysrgb&h=400&w=300"
                alt="Volunteers packing food"
                className="w-full h-48 object-cover rounded-2xl shadow-card animate-float"
                style={{ animationDelay: '0s' }}
              />
              <img
                src="https://images.pexels.com/photos/9705821/pexels-photo-9705821.jpeg?auto=compress&cs=tinysrgb&h=300&w=300"
                alt="Fresh produce"
                className="w-full h-36 object-cover rounded-2xl shadow-soft"
              />
            </div>
            <div className="space-y-4 mt-8">
              <img
                src="https://images.pexels.com/photos/23947763/pexels-photo-23947763.jpeg?auto=compress&cs=tinysrgb&h=300&w=300"
                alt="Prepared meal"
                className="w-full h-36 object-cover rounded-2xl shadow-soft"
              />
              <img
                src="https://images.pexels.com/photos/6646900/pexels-photo-6646900.jpeg?auto=compress&cs=tinysrgb&h=400&w=300"
                alt="Food delivery"
                className="w-full h-48 object-cover rounded-2xl shadow-card animate-float"
                style={{ animationDelay: '2s' }}
              />
            </div>
            {/* Floating badge */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 glass rounded-2xl shadow-card px-5 py-3 border border-white/40">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-coral animate-pulse" />
                <span className="text-xs font-semibold text-forest-600">12 rescues in progress</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const testimonials = [
  {
    quote: "FOOD ORBIT transformed our nightly food waste into 200+ meals for the shelter next door. The matching is instant and the volunteers are incredible.",
    author: 'Anita Reddy',
    role: 'Head Chef, The Grand Hotel',
    avatar: 'AR',
    rating: 5,
  },
  {
    quote: "We used to throw away 40kg of produce weekly. Now it feeds three community kitchens. This platform is a game-changer for food security.",
    author: 'Rajesh Kumar',
    role: 'Store Manager, GreenLeaf Grocers',
    avatar: 'RK',
    rating: 5,
  },
  {
    quote: "As a volunteer, I love how simple it is. I get a notification, accept with one tap, and within 20 minutes the food is at a shelter. Real impact.",
    author: 'Meera Nair',
    role: 'Top Volunteer - 210 rescues',
    avatar: 'MN',
    rating: 5,
  },
];

function TestimonialsSection() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section ref={ref} className="py-24 bg-midnight relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-citrus/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-coral/5 rounded-full blur-3xl" />
      <div className="relative max-w-7xl mx-auto px-6">
        <SectionHeading
          center
          light
          eyebrow="Voices of Impact"
          title={<>Real stories from the <span className="italic text-citrus">orbit</span></>}
          subtitle={"Hear from the donors, NGOs, and volunteers who make food rescue a daily reality."}
        />
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.author}
              className={`bg-forest-700/40 rounded-2xl p-8 border border-forest-600/30 hover:border-citrus/30 transition-all duration-300 ${inView ? 'animate-scale-in' : 'opacity-0'}`}
              style={{ animationDelay: `${i * 150}ms`, animationFillMode: 'forwards' }}
            >
              <Quote className="w-8 h-8 text-citrus/40 mb-4" />
              <p className="text-sage/90 text-sm leading-relaxed mb-6">{t.quote}</p>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-citrus/20 flex items-center justify-center text-citrus font-bold text-sm">
                  {t.avatar}
                </div>
                <div>
                  <div className="font-semibold text-ivory text-sm">{t.author}</div>
                  <div className="text-sage/50 text-xs">{t.role}</div>
                </div>
                <div className="ml-auto flex gap-0.5">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-3 h-3 fill-citrus text-citrus" />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function LiveRescueFeed() {
  const [activities, setActivities] = useState(rescueActivities);
  const { ref, inView } = useInView<HTMLDivElement>();

  useEffect(() => {
    if (!inView) return;
    const interval = setInterval(() => {
      setActivities((prev) => {
        const rotated = [...prev.slice(1), prev[0]];
        return rotated.map((a, i) => ({
          ...a,
          timestamp: i === 0 ? 'just now' : a.timestamp,
        }));
      });
    }, 4000);
    return () => clearInterval(interval);
  }, [inView]);

  const statusConfig = {
    pickup: { label: 'Pickup', color: 'text-coral', bg: 'bg-coral/15', icon: 'bg-coral' },
    transit: { label: 'In Transit', color: 'text-amber-600', bg: 'bg-amber-100', icon: 'bg-amber-500' },
    delivered: { label: 'Delivered', color: 'text-forest-500', bg: 'bg-forest-50', icon: 'bg-forest-400' },
  };

  return (
    <section ref={ref} className="py-24 bg-ivory">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading
          center
          eyebrow="Live Network"
          title={<>Rescues happening <span className="italic text-coral">right now</span></>}
          subtitle={"A live feed of food rescue activity across the FOOD ORBIT network."}
        />
        <div className="mt-16 max-w-3xl mx-auto space-y-3">
          {activities.slice(0, 5).map((activity, i) => {
            const cfg = statusConfig[activity.status];
            return (
              <div
                key={activity.id}
                className={`flex items-center gap-4 bg-white rounded-2xl p-4 shadow-soft border border-forest-50 hover:shadow-card transition-all ${inView ? 'animate-fade-up' : 'opacity-0'}`}
                style={{ animationDelay: `${i * 80}ms`, animationFillMode: 'forwards' }}
              >
                <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-forest-50 flex items-center justify-center">
                  <div className={`w-2 h-2 rounded-full ${cfg.icon} animate-pulse`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-forest-600 truncate">
                    <span className="font-semibold">{activity.donorName}</span>
                    <span className="text-forest-300"> → </span>
                    <span className="font-semibold">{activity.ngoName}</span>
                  </p>
                  <p className="text-xs text-forest-400 mt-0.5">
                    via {activity.volunteerName} · {activity.city}
                  </p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className={`text-xs font-bold text-forest-600`}>{activity.mealsRescued} meals</span>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.color} ${cfg.bg}`}>{cfg.label}</span>
                  <span className="text-xs text-forest-300 hidden sm:inline w-20 text-right">{activity.timestamp}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function CTASection({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <section className="py-24 bg-ivory">
      <div className="max-w-5xl mx-auto px-6">
        <div className="relative bg-forest-600 rounded-3xl p-12 md:p-20 text-center overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-citrus/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-coral/10 rounded-full blur-3xl" />
          <div className="relative">
            <Badge color="text-citrus" bg="bg-citrus/10" className="mb-6">
              <Leaf className="w-3 h-3" /> Join the Orbit
            </Badge>
            <h2 className="font-serif text-4xl md:text-5xl text-ivory leading-tight mb-6 text-balance">
              Your surplus food could be<br />someone's <span className="italic text-citrus">next meal</span>
            </h2>
            <p className="text-sage/70 text-lg max-w-xl mx-auto mb-10">
              Whether you're a restaurant with leftover trays, an NGO that serves meals, or a volunteer with a bike — there's a place for you in the orbit.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" variant="secondary" onClick={() => onNavigate('dashboard')}>
                Start Donating <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="coral" onClick={() => onNavigate('network')}>
                Join as NGO or Volunteer
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function LandingPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <>
      <HeroSection onNavigate={onNavigate} />
      <StatsSection />
      <HowItWorksSection />
      <FeaturesSection />
      <LiveRescueFeed />
      <TestimonialsSection />
      <CTASection onNavigate={onNavigate} />
    </>
  );
}
