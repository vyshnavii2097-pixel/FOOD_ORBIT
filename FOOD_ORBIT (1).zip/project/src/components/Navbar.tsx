import { useState, useEffect } from 'react';
import { Leaf, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/Button';

type Page = 'home' | 'dashboard' | 'listings' | 'network' | 'impact';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const navLinks: { label: string; page: Page }[] = [
  { label: 'Home', page: 'home' },
  { label: 'Dashboard', page: 'dashboard' },
  { label: 'Surplus Listings', page: 'listings' },
  { label: 'Network', page: 'network' },
  { label: 'Impact', page: 'impact' },
];

export function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const handleNav = (page: Page) => {
    onNavigate(page);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'glass shadow-soft py-3' : 'py-5 bg-transparent'}`}>
      <nav className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <button onClick={() => handleNav('home')} className="flex items-center gap-2.5 group">
          <div className="w-10 h-10 rounded-xl bg-forest-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Leaf className="w-5 h-5 text-citrus" strokeWidth={2} />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-bold text-forest-600 text-lg tracking-tight">FOOD ORBIT</span>
            <span className="text-[10px] text-forest-400 tracking-widest uppercase">Every Surplus Has a Purpose</span>
          </div>
        </button>

        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <button
              key={link.page}
              onClick={() => handleNav(link.page)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                currentPage === link.page
                  ? 'bg-forest-600 text-ivory shadow-soft'
                  : 'text-forest-500 hover:bg-forest-50'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-3">
          <button className="text-sm font-semibold text-forest-500 hover:text-forest-600 transition-colors">Sign In</button>
          <Button size="sm" onClick={() => handleNav('dashboard')}>Get Started</Button>
        </div>

        <button className="lg:hidden p-2 text-forest-600" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {mobileOpen && (
        <div className="lg:hidden glass border-t border-forest-100 mt-3 animate-fade-in">
          <div className="px-6 py-4 flex flex-col gap-2">
            {navLinks.map((link) => (
              <button
                key={link.page}
                onClick={() => handleNav(link.page)}
                className={`px-4 py-3 rounded-lg text-sm font-semibold text-left transition-all ${
                  currentPage === link.page ? 'bg-forest-600 text-ivory' : 'text-forest-500 hover:bg-forest-50'
                }`}
              >
                {link.label}
              </button>
            ))}
            <Button size="sm" className="mt-2" onClick={() => handleNav('dashboard')}>Get Started</Button>
          </div>
        </div>
      )}
    </header>
  );
}

export type { Page };
