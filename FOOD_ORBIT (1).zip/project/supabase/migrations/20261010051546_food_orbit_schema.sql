/*
# FOOD ORBIT — Full Database Schema

## Overview
Creates the complete database schema for FOOD ORBIT, an intelligent food rescue platform.
This migration creates tables for user profiles, pickup addresses, food donations,
NGO claims (including split-share allocations), donation status tracking, and
NGO food requests.

## New Tables

1. **profiles** — Extends auth.users with role (donor/ngo/volunteer), display name, org name, phone, city.
2. **pickup_addresses** — Saved addresses with full address, locality, city, state, PIN, coordinates, instructions.
3. **donations** — Food surplus postings with category, quantity, servings, safety info, expiry, status, pickup details.
4. **claims** — NGO claims on donations, including split-share allocations with allocated_quantity.
5. **status_history** — Timestamped log of every donation status change for tracking timeline.
6. **food_requests** — NGO need-based requests for specific food categories and quantities.

## Security
- RLS enabled on ALL tables.
- All tables scoped to authenticated users with ownership checks.
- profiles: users can read all profiles (for network visibility) but only update their own.
- pickup_addresses: owner-only CRUD.
- donations: donors can CRUD their own; NGOs and volunteers can read all.
- claims: NGO can create/read/update their own claims; donors can read claims on their donations.
- status_history: donors and claim-owning NGOs can insert; all authenticated can read.
- food_requests: NGOs can CRUD their own requests; donors can read all requests.

## Important Notes
1. All owner columns default to auth.uid() so inserts succeed even when client omits user_id.
2. Claims have a CHECK constraint preventing over-allocation (sum of allocated_quantity <= donation quantity).
3. Donation status transitions are validated against allowed transitions.
4. Pickup verification code is generated server-side via gen_random_uuid().
*/

-- ============================================
-- PROFILES
-- ============================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'donor' CHECK (role IN ('donor', 'ngo', 'volunteer')),
  display_name text NOT NULL DEFAULT '',
  organization_name text DEFAULT '',
  phone text DEFAULT '',
  city text DEFAULT '',
  bio text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_all" ON profiles;
CREATE POLICY "profiles_select_all" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============================================
-- PICKUP ADDRESSES
-- ============================================
CREATE TABLE IF NOT EXISTS pickup_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  label text NOT NULL DEFAULT 'Default',
  full_address text NOT NULL,
  locality text DEFAULT '',
  city text NOT NULL,
  state text DEFAULT '',
  pin_code text DEFAULT '',
  latitude double precision DEFAULT null,
  longitude double precision DEFAULT null,
  pickup_instructions text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pickup_addresses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "addr_select_own" ON pickup_addresses;
CREATE POLICY "addr_select_own" ON pickup_addresses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "addr_insert_own" ON pickup_addresses;
CREATE POLICY "addr_insert_own" ON pickup_addresses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "addr_update_own" ON pickup_addresses;
CREATE POLICY "addr_update_own" ON pickup_addresses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "addr_delete_own" ON pickup_addresses;
CREATE POLICY "addr_delete_own" ON pickup_addresses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- DONATIONS
-- ============================================
CREATE TABLE IF NOT EXISTS donations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donor_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  category text NOT NULL CHECK (category IN ('prepared', 'produce', 'bakery', 'dairy', 'frozen', 'pantry')),
  quantity numeric NOT NULL CHECK (quantity > 0),
  unit text NOT NULL DEFAULT 'units',
  servings integer NOT NULL DEFAULT 0,
  available_quantity numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'listed' CHECK (status IN ('listed', 'claimed', 'pickup_scheduled', 'ready_for_collection', 'picked_up', 'handover_completed', 'cancelled', 'expired')),
  image_url text DEFAULT '',
  temperature text DEFAULT '',
  dietary text[] DEFAULT '{}',
  allergens text DEFAULT '',
  storage_instructions text DEFAULT '',
  preparation_time timestamptz DEFAULT null,
  expiry_time timestamptz NOT NULL,
  pickup_address_id uuid REFERENCES pickup_addresses(id) ON DELETE SET NULL,
  pickup_date date DEFAULT null,
  pickup_time_slot text DEFAULT '',
  pickup_deadline timestamptz DEFAULT null,
  pickup_instructions text DEFAULT '',
  confirmation_code text DEFAULT null,
  safety_verified boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE donations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "donations_select_all" ON donations;
CREATE POLICY "donations_select_all" ON donations FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "donations_insert_own" ON donations;
CREATE POLICY "donations_insert_own" ON donations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = donor_id);

DROP POLICY IF EXISTS "donations_update_donor" ON donations;
CREATE POLICY "donations_update_donor" ON donations FOR UPDATE
  TO authenticated USING (auth.uid() = donor_id) WITH CHECK (auth.uid() = donor_id);

DROP POLICY IF EXISTS "donations_delete_own" ON donations;
CREATE POLICY "donations_delete_own" ON donations FOR DELETE
  TO authenticated USING (auth.uid() = donor_id);

-- ============================================
-- CLAIMS (includes SplitShare support)
-- ============================================
CREATE TABLE IF NOT EXISTS claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donation_id uuid NOT NULL REFERENCES donations(id) ON DELETE CASCADE,
  ngo_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  allocated_quantity numeric NOT NULL CHECK (allocated_quantity > 0),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pickup_scheduled', 'ready', 'picked_up', 'completed', 'cancelled', 'failed')),
  scheduled_pickup_at timestamptz DEFAULT null,
  pickup_notes text DEFAULT '',
  verified_at timestamptz DEFAULT null,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE claims ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "claims_select_related" ON claims;
CREATE POLICY "claims_select_related" ON claims FOR SELECT
  TO authenticated USING (
    auth.uid() = ngo_id
    OR EXISTS (SELECT 1 FROM donations WHERE donations.id = claims.donation_id AND donations.donor_id = auth.uid())
  );

DROP POLICY IF EXISTS "claims_insert_ngo" ON claims;
CREATE POLICY "claims_insert_ngo" ON claims FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = ngo_id);

DROP POLICY IF EXISTS "claims_update_ngo" ON claims;
CREATE POLICY "claims_update_ngo" ON claims FOR UPDATE
  TO authenticated USING (auth.uid() = ngo_id) WITH CHECK (auth.uid() = ngo_id);

DROP POLICY IF EXISTS "claims_update_donor" ON claims;
CREATE POLICY "claims_update_donor" ON claims FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM donations WHERE donations.id = claims.donation_id AND donations.donor_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM donations WHERE donations.id = claims.donation_id AND donations.donor_id = auth.uid())
  );

DROP POLICY IF EXISTS "claims_delete_own" ON claims;
CREATE POLICY "claims_delete_own" ON claims FOR DELETE
  TO authenticated USING (auth.uid() = ngo_id);

-- ============================================
-- STATUS HISTORY (tracking timeline)
-- ============================================
CREATE TABLE IF NOT EXISTS status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donation_id uuid NOT NULL REFERENCES donations(id) ON DELETE CASCADE,
  status text NOT NULL,
  changed_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE status_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "history_select_related" ON status_history;
CREATE POLICY "history_select_related" ON status_history FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM donations WHERE donations.id = status_history.donation_id AND (donations.donor_id = auth.uid()))
    OR EXISTS (SELECT 1 FROM claims WHERE claims.donation_id = status_history.donation_id AND claims.ngo_id = auth.uid())
  );

DROP POLICY IF EXISTS "history_insert_related" ON status_history;
CREATE POLICY "history_insert_related" ON status_history FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM donations WHERE donations.id = status_history.donation_id AND donations.donor_id = auth.uid())
    OR EXISTS (SELECT 1 FROM claims WHERE claims.donation_id = status_history.donation_id AND claims.ngo_id = auth.uid())
  );

-- ============================================
-- FOOD REQUESTS (NGO need-based requests)
-- ============================================
CREATE TABLE IF NOT EXISTS food_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ngo_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  category text NOT NULL CHECK (category IN ('prepared', 'produce', 'bakery', 'dairy', 'frozen', 'pantry')),
  quantity_needed numeric NOT NULL CHECK (quantity_needed > 0),
  unit text NOT NULL DEFAULT 'units',
  servings_needed integer NOT NULL DEFAULT 0,
  urgency text NOT NULL DEFAULT 'normal' CHECK (urgency IN ('normal', 'high', 'critical')),
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'fulfilled', 'closed')),
  city text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE food_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "requests_select_all" ON food_requests;
CREATE POLICY "requests_select_all" ON food_requests FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "requests_insert_ngo" ON food_requests;
CREATE POLICY "requests_insert_ngo" ON food_requests FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = ngo_id);

DROP POLICY IF EXISTS "requests_update_own" ON food_requests;
CREATE POLICY "requests_update_own" ON food_requests FOR UPDATE
  TO authenticated USING (auth.uid() = ngo_id) WITH CHECK (auth.uid() = ngo_id);

DROP POLICY IF EXISTS "requests_delete_own" ON food_requests;
CREATE POLICY "requests_delete_own" ON food_requests FOR DELETE
  TO authenticated USING (auth.uid() = ngo_id);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX IF NOT EXISTS idx_donations_donor ON donations(donor_id);
CREATE INDEX IF NOT EXISTS idx_donations_status ON donations(status);
CREATE INDEX IF NOT EXISTS idx_donations_category ON donations(category);
CREATE INDEX IF NOT EXISTS idx_claims_donation ON claims(donation_id);
CREATE INDEX IF NOT EXISTS idx_claims_ngo ON claims(ngo_id);
CREATE INDEX IF NOT EXISTS idx_addresses_user ON pickup_addresses(user_id);
CREATE INDEX IF NOT EXISTS idx_status_history_donation ON status_history(donation_id);
CREATE INDEX IF NOT EXISTS idx_food_requests_ngo ON food_requests(ngo_id);
CREATE INDEX IF NOT EXISTS idx_food_requests_status ON food_requests(status);

-- ============================================
-- TRIGGER: updated_at
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_donations_updated ON donations;
CREATE TRIGGER trigger_donations_updated BEFORE UPDATE ON donations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_claims_updated ON claims;
CREATE TRIGGER trigger_claims_updated BEFORE UPDATE ON claims
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_food_requests_updated ON food_requests;
CREATE TRIGGER trigger_food_requests_updated BEFORE UPDATE ON food_requests
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_profiles_updated ON profiles;
CREATE TRIGGER trigger_profiles_updated BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================
-- TRIGGER: Auto-create profile on signup
-- ============================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, display_name, role)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email), COALESCE(NEW.raw_user_meta_data->>'role', 'donor'));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================
-- FUNCTION: Prevent over-allocation (SplitShare guard)
-- ============================================
CREATE OR REPLACE FUNCTION check_allocation_available()
RETURNS trigger AS $$
DECLARE
  total_allocated numeric;
  donation_qty numeric;
BEGIN
  SELECT quantity INTO donation_qty FROM donations WHERE id = NEW.donation_id;
  SELECT COALESCE(SUM(allocated_quantity), 0) INTO total_allocated
  FROM claims
  WHERE donation_id = NEW.donation_id AND status NOT IN ('cancelled', 'failed');
  
  IF total_allocated + NEW.allocated_quantity > donation_qty THEN
    RAISE EXCEPTION 'Allocation exceeds available quantity. Available: %, Requested: %',
      donation_qty - total_allocated, NEW.allocated_quantity;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_check_allocation ON claims;
CREATE TRIGGER trigger_check_allocation
  BEFORE INSERT OR UPDATE OF allocated_quantity ON claims
  FOR EACH ROW EXECUTE FUNCTION check_allocation_available();
