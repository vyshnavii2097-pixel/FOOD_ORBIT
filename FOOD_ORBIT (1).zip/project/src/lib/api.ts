import { supabase } from '@/lib/supabase';
import type {
  Donation,
  PickupAddress,
  Claim,
  StatusHistoryEntry,
  FoodRequest,
  Profile,
  FoodCategory,
  DonationStatus,
  UserRole,
} from '@/types';

// ============================================
// ADDRESSES
// ============================================

export async function getAddresses(): Promise<PickupAddress[]> {
  const { data, error } = await supabase
    .from('pickup_addresses')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as PickupAddress[];
}

export async function createAddress(addr: Omit<PickupAddress, 'id' | 'user_id' | 'created_at'>): Promise<PickupAddress> {
  const { data, error } = await supabase
    .from('pickup_addresses')
    .insert(addr)
    .select()
    .single();
  if (error) throw error;
  return data as PickupAddress;
}

// ============================================
// DONATIONS
// ============================================

export async function getDonations(filters?: {
  status?: DonationStatus;
  category?: FoodCategory;
  donorId?: string;
  search?: string;
}): Promise<Donation[]> {
  let query = supabase
    .from('donations')
    .select(`
      *,
      donor_profile:profiles!donor_id(id, display_name, organization_name, role, city),
      pickup_address:pickup_addresses(*)
    `)
    .order('created_at', { ascending: false });

  if (filters?.status) query = query.eq('status', filters.status);
  if (filters?.category) query = query.eq('category', filters.category);
  if (filters?.donorId) query = query.eq('donor_id', filters.donorId);

  const { data, error } = await query;
  if (error) throw error;

  let donations = data as Donation[];

  if (filters?.search) {
    const q = filters.search.toLowerCase();
    donations = donations.filter(
      (d) =>
        d.title.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q) ||
        (d.donor_profile?.organization_name || '').toLowerCase().includes(q) ||
        (d.donor_profile?.display_name || '').toLowerCase().includes(q)
    );
  }

  return donations;
}

export async function getDonationById(id: string): Promise<Donation | null> {
  const { data, error } = await supabase
    .from('donations')
    .select(`
      *,
      donor_profile:profiles!donor_id(id, display_name, organization_name, role, city),
      pickup_address:pickup_addresses(*)
    `)
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Donation | null;
}

export interface CreateDonationInput {
  title: string;
  description: string;
  category: FoodCategory;
  quantity: number;
  unit: string;
  servings: number;
  image_url: string;
  temperature: string;
  dietary: string[];
  allergens: string;
  storage_instructions: string;
  preparation_time: string | null;
  expiry_time: string;
  pickup_address_id: string;
  pickup_date: string | null;
  pickup_time_slot: string;
  pickup_deadline: string | null;
  pickup_instructions: string;
  safety_verified: boolean;
}

export async function createDonation(input: CreateDonationInput): Promise<Donation> {
  const code = Math.random().toString(36).substring(2, 8).toUpperCase();

  const { data, error } = await supabase
    .from('donations')
    .insert({
      ...input,
      available_quantity: input.quantity,
      confirmation_code: code,
    })
    .select()
    .single();
  if (error) throw error;

  const donation = data as Donation;

  // Insert initial status history
  await supabase.from('status_history').insert({
    donation_id: donation.id,
    status: 'listed',
    notes: 'Donation posted',
  });

  return donation;
}

export async function updateDonationStatus(donationId: string, status: DonationStatus, notes: string = ''): Promise<void> {
  const { error: updateError } = await supabase
    .from('donations')
    .update({ status })
    .eq('id', donationId);
  if (updateError) throw updateError;

  const { error: historyError } = await supabase.from('status_history').insert({
    donation_id: donationId,
    status,
    notes,
  });
  if (historyError) throw historyError;
}

export async function getStatusHistory(donationId: string): Promise<StatusHistoryEntry[]> {
  const { data, error } = await supabase
    .from('status_history')
    .select(`
      *,
      changed_by_profile:profiles!changed_by(id, display_name, organization_name, role)
    `)
    .eq('donation_id', donationId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data as StatusHistoryEntry[];
}

// ============================================
// CLAIMS (including SplitShare)
// ============================================

export async function getClaimsForDonation(donationId: string): Promise<Claim[]> {
  const { data, error } = await supabase
    .from('claims')
    .select(`
      *,
      ngo_profile:profiles!ngo_id(id, display_name, organization_name, role, city)
    `)
    .eq('donation_id', donationId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data as Claim[];
}

export async function getClaimsByNgo(ngoId: string): Promise<Claim[]> {
  const { data, error } = await supabase
    .from('claims')
    .select(`
      *,
      donation:donations(
        *,
        donor_profile:profiles!donor_id(id, display_name, organization_name, role, city),
        pickup_address:pickup_addresses(*)
      )
    `)
    .eq('ngo_id', ngoId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as Claim[];
}

export async function getClaimsForDonor(donorId: string): Promise<Claim[]> {
  const { data, error } = await supabase
    .from('claims')
    .select(`
      *,
      ngo_profile:profiles!ngo_id(id, display_name, organization_name, role, city),
      donation:donations!inner(id, donor_id, title, status)
    `)
    .eq('donation.donor_id', donorId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as Claim[];
}

export async function createClaim(
  donationId: string,
  ngoId: string,
  allocatedQuantity: number,
  pickupNotes: string = ''
): Promise<Claim> {
  const { data, error } = await supabase
    .from('claims')
    .insert({
      donation_id: donationId,
      ngo_id: ngoId,
      allocated_quantity: allocatedQuantity,
      pickup_notes: pickupNotes,
    })
    .select()
    .single();

  if (error) {
    if (error.message.includes('Allocation exceeds')) {
      throw new Error('The requested quantity exceeds what is available for this donation.');
    }
    if (error.code === '23505') {
      throw new Error('You have already claimed this donation.');
    }
    throw error;
  }

  return data as Claim;
}

export async function updateClaimStatus(
  claimId: string,
  status: Claim['status'],
  scheduledPickupAt?: string | null,
  pickupNotes?: string
): Promise<void> {
  const update: Record<string, unknown> = { status };
  if (scheduledPickupAt !== undefined) update.scheduled_pickup_at = scheduledPickupAt;
  if (pickupNotes !== undefined) update.pickup_notes = pickupNotes;
  if (status === 'picked_up' || status === 'completed') {
    update.verified_at = new Date().toISOString();
  }

  const { error } = await supabase.from('claims').update(update).eq('id', claimId);
  if (error) throw error;
}

export async function cancelClaim(claimId: string): Promise<void> {
  const { error } = await supabase
    .from('claims')
    .update({ status: 'cancelled' })
    .eq('id', claimId);
  if (error) throw error;
}

// ============================================
// SMART MATCHING
// ============================================

export interface MatchedNGO {
  profile: Profile;
  totalClaimed: number;
  matchScore: number;
  matchReasons: string[];
}

export async function findMatchingNGOs(donation: Donation): Promise<MatchedNGO[]> {
  const { data: ngoProfiles, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('role', 'ngo')
    .order('display_name');
  if (error) throw error;

  const { data: claims, error: claimsError } = await supabase
    .from('claims')
    .select('ngo_id, allocated_quantity, status')
    .in('ngo_id', (ngoProfiles || []).map((n) => n.id))
    .neq('status', 'cancelled');
  if (claimsError) throw claimsError;

  const results: MatchedNGO[] = (ngoProfiles || []).map((np) => {
    const profile = np as Profile;
    const ngoClaims = (claims || []).filter((c) => c.ngo_id === profile.id);
    const totalClaimed = ngoClaims.reduce((sum, c) => sum + c.allocated_quantity, 0);

    const reasons: string[] = [];
    let score = 50;

    if (profile.city && donation.donor_profile?.city && profile.city === donation.donor_profile.city) {
      score += 30;
      reasons.push('Same city');
    }

    if (donation.servings >= 50) {
      score += 10;
      reasons.push('High servings');
    }

    if (totalClaimed < 200) {
      score += 15;
      reasons.push('Available capacity');
    }

    if (totalClaimed < 50) {
      score += 10;
      reasons.push('Low current load');
    }

    if (reasons.length === 0) reasons.push('Eligible NGO partner');

    return { profile, totalClaimed, matchScore: score, matchReasons: reasons };
  });

  return results.sort((a, b) => b.matchScore - a.matchScore).slice(0, 5);
}

// ============================================
// FOOD REQUESTS
// ============================================

export async function getFoodRequests(status?: string): Promise<FoodRequest[]> {
  let query = supabase
    .from('food_requests')
    .select(`
      *,
      ngo_profile:profiles!ngo_id(id, display_name, organization_name, role, city)
    `)
    .order('created_at', { ascending: false });

  if (status) query = query.eq('status', status);

  const { data, error } = await query;
  if (error) throw error;
  return data as FoodRequest[];
}

export async function createFoodRequest(input: {
  category: FoodCategory;
  quantity_needed: number;
  unit: string;
  servings_needed: number;
  urgency: 'normal' | 'high' | 'critical';
  description: string;
  city: string;
}): Promise<FoodRequest> {
  const { data, error } = await supabase
    .from('food_requests')
    .insert(input)
    .select()
    .single();
  if (error) throw error;
  return data as FoodRequest;
}

export async function updateFoodRequestStatus(requestId: string, status: 'open' | 'fulfilled' | 'closed'): Promise<void> {
  const { error } = await supabase
    .from('food_requests')
    .update({ status })
    .eq('id', requestId);
  if (error) throw error;
}

// ============================================
// NGO PROFILES
// ============================================

export async function getNGOProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('role', 'ngo')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as Profile[];
}

export async function getVolunteerProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('role', 'volunteer')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as Profile[];
}

// ============================================
// IMPACT STATS
// ============================================

export async function getImpactStats() {
  const { data: donations, error: dError } = await supabase
    .from('donations')
    .select('status, quantity, servings, category');
  if (dError) throw dError;

  const { data: claims, error: cError } = await supabase
    .from('claims')
    .select('allocated_quantity, status')
    .eq('status', 'completed');
  if (cError) throw cError;

  const { count: donorCount, error: donorErr } = await supabase
    .from('profiles')
    .select('*', { count: 'exact', head: true })
    .eq('role', 'donor');
  if (donorErr) throw donorErr;

  const { count: ngoCount, error: ngoErr } = await supabase
    .from('profiles')
    .select('*', { count: 'exact', head: true })
    .eq('role', 'ngo');
  if (ngoErr) throw ngoErr;

  const { count: volunteerCount, error: volErr } = await supabase
    .from('profiles')
    .select('*', { count: 'exact', head: true })
    .eq('role', 'volunteer');
  if (volErr) throw volErr;

  const completedDonations = (donations || []).filter((d) => d.status === 'handover_completed');
  const totalMeals = completedDonations.reduce((sum, d) => sum + (d.servings || 0), 0);
  const totalQuantity = completedDonations.reduce((sum, d) => sum + Number(d.quantity || 0), 0);
  const co2Diverted = totalMeals * 0.37;

  const categoryBreakdown: Record<string, number> = {};
  (donations || []).forEach((d) => {
    categoryBreakdown[d.category] = (categoryBreakdown[d.category] || 0) + 1;
  });

  return {
    totalDonations: donations?.length || 0,
    completedDonations: completedDonations.length,
    totalMeals,
    totalQuantity,
    co2Diverted: parseFloat(co2Diverted.toFixed(1)),
    donorCount: donorCount || 0,
    ngoCount: ngoCount || 0,
    volunteerCount: volunteerCount || 0,
    activeDonations: (donations || []).filter((d) =>
      ['listed', 'claimed', 'pickup_scheduled', 'ready_for_collection', 'picked_up'].includes(d.status)
    ).length,
    categoryBreakdown,
  };
}

// ============================================
// PROFILE
// ============================================

export async function updateProfile(updates: {
  display_name?: string;
  organization_name?: string;
  phone?: string;
  city?: string;
  bio?: string;
}): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', user.id);
  if (error) throw error;
}

// Helper to check if user can modify a donation
export function canModifyDonation(
  userRole: UserRole | undefined,
  userId: string | undefined,
  donation: { donor_id: string }
): boolean {
  if (!userRole || !userId) return false;
  if (userRole === 'donor' && donation.donor_id === userId) return true;
  return false;
}
