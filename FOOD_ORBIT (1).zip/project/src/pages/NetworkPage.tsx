import { useState } from 'react';
import {
  HeartHandshake, Bike, Star, MapPin, Users, Utensils, Award,
  TrendingUp, Search, ArrowRight, Zap, Clock,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { useInView, useCountUp } from '@/hooks/useInView';
import { ngos, volunteers } from '@/data/mockData';
import type { Page } from '@/components/Navbar';

function NGOCard({ ngo, index }: { ngo: typeof ngos[0]; index: number }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const mealsValue = useCountUp(ngo.mealsRescued, 1500, inView);
  return (
    <div
      ref={ref}
      className={`bg-white rounded-2xl p-6 shadow-soft border border-forest-50 hover:shadow-card hover:border-citrus/30 transition-all duration-300 ${inView ? 'animate-scale-in' : 'opacity-0'}`}
      style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-forest-600 flex items-center justify-center text-citrus font-bold text-lg">
            {ngo.avatar}
          </div>
          <div>
            <h3 className="font-semibold text-forest-600">{ngo.name}</h3>
            <p className="text-xs text-forest-400">{ngo.type}</p>
          </div>
        </div>
        <Badge color="text-citrus-dark" bg="bg-citrus/15">
          <Award className="w-3 h-3" /> {ngo.badge}
        </Badge>
      </div>

      <div className="flex items-center gap-1 mb-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={`w-3.5 h-3.5 ${i < Math.floor(ngo.rating) ? 'fill-citrus text-citrus' : 'text-forest-100'}`}
          />
        ))}
        <span className="text-xs font-semibold text-forest-500 ml-1">{ngo.rating}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-forest-50/50 rounded-xl p-3">
          <div className="flex items-center gap-1.5 text-forest-400 text-xs mb-1">
            <Users className="w-3 h-3" /> People Served
          </div>
          <div className="text-lg font-bold text-forest-600">{ngo.peopleServed}</div>
        </div>
        <div className="bg-forest-50/50 rounded-xl p-3">
          <div className="flex items-center gap-1.5 text-forest-400 text-xs mb-1">
            <Utensils className="w-3 h-3" /> Meals Rescued
          </div>
          <div className="text-lg font-bold text-forest-600">{mealsValue.toLocaleString()}</div>
        </div>
      </div>

      <div className="flex items-center gap-2 text-xs text-forest-400 mb-4">
        <MapPin className="w-3.5 h-3.5" />
        {ngo.location}
      </div>

      <div className="flex items-center justify-between mb-4">
        <span className="text-xs text-forest-400">Daily capacity</span>
        <div className="flex-1 mx-3 h-2 bg-forest-50 rounded-full overflow-hidden">
          <div
            className="h-full bg-forest-400 rounded-full"
            style={{ width: `${Math.min((ngo.mealsRescued / (ngo.capacityPerDay * 30)) * 100, 100)}%` }}
          />
        </div>
        <span className="text-xs font-semibold text-forest-500">{ngo.capacityPerDay}/day</span>
      </div>

      <Button size="sm" variant="outline" className="w-full">
        Connect <ArrowRight className="w-4 h-4" />
      </Button>
    </div>
  );
}

function VolunteerCard({ vol, index }: { vol: typeof volunteers[0]; index: number }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const rescuesValue = useCountUp(vol.rescuesCompleted, 1200, inView);
  return (
    <div
      ref={ref}
      className={`bg-white rounded-2xl p-6 shadow-soft border border-forest-50 hover:shadow-card hover:border-citrus/30 transition-all duration-300 ${inView ? 'animate-scale-in' : 'opacity-0'}`}
      style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-full bg-citrus/20 flex items-center justify-center text-forest-600 font-bold text-lg">
            {vol.avatar}
          </div>
          <div>
            <h3 className="font-semibold text-forest-600">{vol.name}</h3>
            <p className="text-xs text-forest-400">{vol.activeCity} · Since {vol.joinedDate}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Star className="w-3.5 h-3.5 fill-citrus text-citrus" />
          <span className="text-xs font-semibold text-forest-500">{vol.rating}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-forest-50/50 rounded-xl p-3">
          <div className="flex items-center gap-1.5 text-forest-400 text-xs mb-1">
            <Bike className="w-3 h-3" /> Rescues
          </div>
          <div className="text-lg font-bold text-forest-600">{rescuesValue}</div>
        </div>
        <div className="bg-forest-50/50 rounded-xl p-3">
          <div className="flex items-center gap-1.5 text-forest-400 text-xs mb-1">
            <Utensils className="w-3 h-3" /> Meals Delivered
          </div>
          <div className="text-lg font-bold text-forest-600">{vol.mealsDelivered.toLocaleString()}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {vol.badges.map((badge) => (
          <span key={badge} className="text-xs font-semibold px-2.5 py-1 rounded-full bg-citrus/10 text-citrus-dark">
            {badge}
          </span>
        ))}
      </div>
    </div>
  );
}

function JoinCTA({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const roles = [
    {
      icon: HeartHandshake,
      title: 'Join as NGO / Kitchen',
      desc: 'Receive surplus food matches and feed your community.',
      points: ['Smart match notifications', 'Capacity-based matching', 'Impact tracking dashboard'],
      cta: 'Register Organization',
      color: 'bg-forest-600',
    },
    {
      icon: Bike,
      title: 'Join as Volunteer',
      desc: 'Pick up and deliver food to those who need it most.',
      points: ['Flexible mission scheduling', 'Route-optimized pickups', 'Earn impact badges'],
      cta: 'Become a Volunteer',
      color: 'bg-coral',
    },
  ];

  return (
    <section className="py-20 bg-ivory">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeading
          center
          eyebrow="Join the Network"
          title={<>Be part of the <span className="italic text-coral">solution</span></>}
          subtitle="Every role in the orbit is essential. Choose yours and start making an impact today."
        />
        <div className="grid md:grid-cols-2 gap-6 mt-12">
          {roles.map((role) => (
            <div key={role.title} className="bg-white rounded-2xl p-8 shadow-soft border border-forest-50 hover:shadow-card transition-all">
              <div className={`w-14 h-14 rounded-2xl ${role.color} flex items-center justify-center mb-5`}>
                <role.icon className="w-7 h-7 text-ivory" strokeWidth={1.5} />
              </div>
              <h3 className="font-serif text-2xl text-forest-600 mb-2">{role.title}</h3>
              <p className="text-forest-400 text-sm mb-5">{role.desc}</p>
              <ul className="space-y-2 mb-6">
                {role.points.map((point) => (
                  <li key={point} className="flex items-center gap-2 text-sm text-forest-500">
                    <div className="w-1.5 h-1.5 rounded-full bg-citrus-dark" />
                    {point}
                  </li>
                ))}
              </ul>
              <Button variant="outline" className="w-full" onClick={() => onNavigate('dashboard')}>
                {role.cta} <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function NetworkPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const [tab, setTab] = useState<'ngos' | 'volunteers'>('ngos');
  const [search, setSearch] = useState('');

  const filteredNgos = ngos.filter((n) =>
    n.name.toLowerCase().includes(search.toLowerCase()) ||
    n.location.toLowerCase().includes(search.toLowerCase()) ||
    n.type.toLowerCase().includes(search.toLowerCase())
  );
  const filteredVolunteers = volunteers.filter((v) =>
    v.name.toLowerCase().includes(search.toLowerCase()) ||
    v.activeCity.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-24 pb-12 bg-sage/20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <h1 className="font-serif text-4xl text-forest-600">Rescue Network</h1>
          <p className="text-forest-400 mt-2">NGOs, community kitchens, and volunteers working to end food waste.</p>
        </div>

        {/* Network summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'NGO Partners', value: '34', icon: HeartHandshake, color: 'text-forest-500', bg: 'bg-forest-50' },
            { label: 'Active Volunteers', value: '189', icon: Bike, color: 'text-citrus-dark', bg: 'bg-citrus/10' },
            { label: 'People Served', value: '12.4K', icon: Users, color: 'text-coral-dark', bg: 'bg-coral/10' },
            { label: 'Cities', value: '12', icon: MapPin, color: 'text-forest-600', bg: 'bg-sage' },
          ].map((stat) => (
            <div key={stat.label} className="bg-white rounded-2xl p-5 shadow-soft border border-forest-50">
              <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} strokeWidth={1.5} />
              </div>
              <div className="text-2xl font-bold text-forest-600">{stat.value}</div>
              <div className="text-xs text-forest-400 mt-0.5">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Tab switcher + search */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex items-center gap-1 bg-white rounded-xl p-1 shadow-soft">
            {[
              { id: 'ngos' as const, label: 'NGOs & Kitchens', icon: HeartHandshake },
              { id: 'volunteers' as const, label: 'Volunteers', icon: Bike },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                  tab === t.id ? 'bg-forest-600 text-ivory shadow-soft' : 'text-forest-400 hover:bg-forest-50'
                }`}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
              </button>
            ))}
          </div>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-forest-300" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tab === 'ngos' ? 'Search NGOs by name or location...' : 'Search volunteers by name or city...'}
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-white border border-forest-50 text-sm text-forest-600 placeholder:text-forest-300 focus:outline-none focus:border-forest-400 transition-colors shadow-soft"
            />
          </div>
        </div>

        {/* Cards grid */}
        {tab === 'ngos' ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredNgos.map((ngo, i) => (
              <NGOCard key={ngo.id} ngo={ngo} index={i} />
            ))}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredVolunteers.map((vol, i) => (
              <VolunteerCard key={vol.id} vol={vol} index={i} />
            ))}
          </div>
        )}
      </div>

      {/* Join CTA */}
      <div className="mt-16">
        <JoinCTA onNavigate={onNavigate} />
      </div>
    </div>
  );
}
