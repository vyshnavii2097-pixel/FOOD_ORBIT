import { useState } from 'react';
import {
  Utensils, Leaf, Store, Users, HeartHandshake, TrendingUp, Clock, MapPin,
  Package, Bike, CheckCircle2, AlertTriangle, Plus, ArrowRight, Bell,
  Thermometer, Truck, Eye, Trash2,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { useInView, useCountUp } from '@/hooks/useInView';
import { surplusListings, rescueActivities, categoryConfig, statusConfig } from '@/data/mockData';
import type { Page } from '@/components/Navbar';

const dashboardStats = [
  { label: 'Active Listings', value: 6, icon: Package, color: 'text-coral', bg: 'bg-coral/10', suffix: '' },
  { label: 'Meals Rescued', value: 3850, icon: Utensils, color: 'text-forest-500', bg: 'bg-forest-50', suffix: '' },
  { label: 'CO₂ Diverted', value: 1.42, icon: Leaf, color: 'text-citrus-dark', bg: 'bg-citrus/10', suffix: 't', decimals: 2 },
  { label: 'This Month', value: 142, icon: TrendingUp, color: 'text-forest-600', bg: 'bg-sage', suffix: '', suffixLabel: 'rescues' },
];

const weeklyData = [
  { day: 'Mon', meals: 420 },
  { day: 'Tue', meals: 580 },
  { day: 'Wed', meals: 340 },
  { day: 'Thu', meals: 720 },
  { day: 'Fri', meals: 890 },
  { day: 'Sat', meals: 650 },
  { day: 'Sun', meals: 480 },
];

function StatCard({ stat, inView }: { stat: typeof dashboardStats[0]; inView: boolean }) {
  const value = useCountUp(stat.value, 1200, inView, stat.decimals || 0);
  return (
    <div className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50 hover:shadow-card transition-all">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center`}>
          <stat.icon className={`w-5 h-5 ${stat.color}`} strokeWidth={1.5} />
        </div>
        <TrendingUp className="w-4 h-4 text-forest-300" />
      </div>
      <div className="text-3xl font-bold text-forest-600">
        {value.toLocaleString()}{stat.suffix}
      </div>
      <div className="text-sm text-forest-400 mt-1">
        {stat.label}{stat.suffixLabel ? ` ${stat.suffixLabel}` : ''}
      </div>
    </div>
  );
}

function WeeklyChart() {
  const { ref, inView } = useInView<HTMLDivElement>();
  const maxMeals = Math.max(...weeklyData.map((d) => d.meals));
  return (
    <div ref={ref} className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold text-forest-600 text-lg">Rescue Activity</h3>
          <p className="text-xs text-forest-400 mt-0.5">Meals rescued this week</p>
        </div>
        <Badge color="text-forest-500" bg="bg-forest-50">+18% vs last week</Badge>
      </div>
      <div className="flex items-end justify-between gap-3 h-40">
        {weeklyData.map((d, i) => {
          const heightPct = (d.meals / maxMeals) * 100;
          return (
            <div key={d.day} className="flex-1 flex flex-col items-center gap-2 group">
              <div className="text-xs font-semibold text-forest-400 opacity-0 group-hover:opacity-100 transition-opacity">
                {d.meals}
              </div>
              <div className="w-full bg-forest-50 rounded-lg overflow-hidden flex items-end" style={{ height: '120px' }}>
                <div
                  className={`w-full rounded-lg transition-all duration-700 ${inView ? '' : 'h-0'} ${
                    d.day === 'Fri' ? 'bg-citrus' : 'bg-forest-400 group-hover:bg-forest-500'
                  }`}
                  style={{
                    height: inView ? `${heightPct}%` : '0%',
                    transitionDelay: `${i * 80}ms`,
                  }}
                />
              </div>
              <span className="text-xs text-forest-400 font-medium">{d.day}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MyListings() {
  const myListings = surplusListings.filter((l) => l.status === 'available' || l.status === 'claimed').slice(0, 4);
  return (
    <div className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-forest-600 text-lg">My Active Listings</h3>
        <Button size="sm" variant="primary"><Plus className="w-4 h-4" /> New Listing</Button>
      </div>
      <div className="space-y-3">
        {myListings.map((listing) => {
          const cat = categoryConfig[listing.category];
          const status = statusConfig[listing.status];
          const urgent = listing.expiresInMin <= 60;
          return (
            <div key={listing.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-forest-50/50 transition-colors group">
              <img src={listing.imageUrl} alt={listing.title} className="w-14 h-14 rounded-xl object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold text-forest-600 text-sm truncate">{listing.title}</h4>
                  {urgent && <AlertTriangle className="w-3.5 h-3.5 text-coral flex-shrink-0" />}
                </div>
                <div className="flex items-center gap-3 mt-1">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${cat.color} ${cat.bg}`}>{cat.label}</span>
                  <span className="text-xs text-forest-400">{listing.servings} servings</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${status.color} ${status.bg}`}>{status.label}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <div className={`text-right ${urgent ? 'text-coral' : 'text-forest-400'}`}>
                  <div className="flex items-center gap-1 text-xs font-semibold">
                    <Clock className="w-3 h-3" />
                    {listing.expiresInMin}m
                  </div>
                </div>
                <button className="p-2 rounded-lg text-forest-300 hover:text-forest-600 hover:bg-forest-50 transition-colors opacity-0 group-hover:opacity-100">
                  <Eye className="w-4 h-4" />
                </button>
                <button className="p-2 rounded-lg text-forest-300 hover:text-coral hover:bg-coral/10 transition-colors opacity-0 group-hover:opacity-100">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ActiveRescues() {
  const active = rescueActivities.filter((a) => a.status !== 'delivered');
  const statusMap = {
    pickup: { label: 'Pickup', icon: Package, color: 'text-coral', bg: 'bg-coral/10' },
    transit: { label: 'In Transit', icon: Truck, color: 'text-amber-600', bg: 'bg-amber-100' },
    delivered: { label: 'Delivered', icon: CheckCircle2, color: 'text-forest-500', bg: 'bg-forest-50' },
  };
  return (
    <div className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-forest-600 text-lg">Active Rescues</h3>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-coral animate-pulse" />
          <span className="text-xs font-semibold text-forest-400">{active.length} in progress</span>
        </div>
      </div>
      <div className="space-y-4">
        {active.map((rescue) => {
          const cfg = statusMap[rescue.status];
          return (
            <div key={rescue.id} className="relative pl-8">
              {/* Timeline line */}
              <div className="absolute left-3 top-0 bottom-0 w-px bg-forest-100" />
              <div className={`absolute left-0 top-1 w-6 h-6 rounded-full ${cfg.bg} flex items-center justify-center`}>
                <cfg.icon className={`w-3 h-3 ${cfg.color}`} />
              </div>
              <div className="pb-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-forest-600">{rescue.donorName}</span>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${cfg.color} ${cfg.bg}`}>{cfg.label}</span>
                </div>
                <p className="text-xs text-forest-400">
                  → {rescue.ngoName} · {rescue.volunteerName}
                </p>
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-xs font-bold text-forest-500">{rescue.mealsRescued} meals</span>
                  <span className="text-xs text-forest-300">·</span>
                  <span className="text-xs text-forest-400">{rescue.timestamp}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function RecentNotifications() {
  const notifications = [
    { icon: Bike, text: 'Volunteer Aarav S. accepted your pasta buffet rescue', time: '2 min ago', color: 'text-citrus-dark', bg: 'bg-citrus/10' },
    { icon: HeartHandshake, text: 'Hope Kitchen Collective claimed your produce listing', time: '15 min ago', color: 'text-forest-500', bg: 'bg-forest-50' },
    { icon: CheckCircle2, text: 'Bread & pastries delivery completed — 80 meals served', time: '1 hr ago', color: 'text-forest-600', bg: 'bg-sage' },
    { icon: AlertTriangle, text: 'Event plated meals expire in 30 minutes — urgent!', time: '5 min ago', color: 'text-coral', bg: 'bg-coral/10' },
  ];
  return (
    <div className="bg-white rounded-2xl p-6 shadow-soft border border-forest-50">
      <div className="flex items-center gap-2 mb-6">
        <Bell className="w-5 h-5 text-forest-500" />
        <h3 className="font-semibold text-forest-600 text-lg">Notifications</h3>
      </div>
      <div className="space-y-3">
        {notifications.map((n, i) => (
          <div key={i} className="flex gap-3 group">
            <div className={`flex-shrink-0 w-9 h-9 rounded-xl ${n.bg} flex items-center justify-center`}>
              <n.icon className={`w-4 h-4 ${n.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-forest-600 leading-snug">{n.text}</p>
              <p className="text-xs text-forest-300 mt-0.5">{n.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function QuickActions({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const actions = [
    { label: 'Post Surplus', icon: Plus, color: 'bg-forest-600', text: 'text-ivory', page: 'listings' as Page },
    { label: 'View Listings', icon: Package, color: 'bg-citrus', text: 'text-forest-600', page: 'listings' as Page },
    { label: 'Find NGOs', icon: HeartHandshake, color: 'bg-coral', text: 'text-white', page: 'network' as Page },
    { label: 'Impact Report', icon: TrendingUp, color: 'bg-forest-500', text: 'text-ivory', page: 'impact' as Page },
  ];
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {actions.map((action) => (
        <button
          key={action.label}
          onClick={() => onNavigate(action.page)}
          className={`${action.color} ${action.text} rounded-2xl p-5 flex items-center gap-3 hover:scale-[1.02] transition-transform shadow-soft`}
        >
          <action.icon className="w-5 h-5" />
          <span className="font-semibold text-sm">{action.label}</span>
        </button>
      ))}
    </div>
  );
}

export function DashboardPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const [role, setRole] = useState<'donor' | 'ngo' | 'volunteer'>('donor');

  const roles = [
    { id: 'donor' as const, label: 'Donor', icon: Store },
    { id: 'ngo' as const, label: 'NGO / Kitchen', icon: HeartHandshake },
    { id: 'volunteer' as const, label: 'Volunteer', icon: Bike },
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 bg-sage/20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="font-serif text-4xl text-forest-600">Welcome back, Aarav</h1>
              <p className="text-forest-400 mt-2">Here's what's happening in your food rescue orbit today.</p>
            </div>
            {/* Role switcher */}
            <div className="flex items-center gap-1 bg-white rounded-xl p-1 shadow-soft">
              {roles.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setRole(r.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    role === r.id ? 'bg-forest-600 text-ivory' : 'text-forest-400 hover:bg-forest-50'
                  }`}
                >
                  <r.icon className="w-4 h-4" />
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <QuickActions onNavigate={onNavigate} />
        </div>

        {/* Stats */}
        <div ref={ref} className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {dashboardStats.map((stat) => (
            <StatCard key={stat.label} stat={stat} inView={inView} />
          ))}
        </div>

        {/* Main grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <WeeklyChart />
            <MyListings />
          </div>
          <div className="space-y-6">
            <ActiveRescues />
            <RecentNotifications />
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-8 bg-forest-600 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-48 h-48 bg-citrus/10 rounded-full blur-3xl" />
          <div className="relative">
            <h3 className="font-serif text-2xl text-ivory mb-2">Have surplus food right now?</h3>
            <p className="text-sage/70 text-sm">Post it in under 60 seconds and get matched instantly.</p>
          </div>
          <Button size="lg" variant="secondary" onClick={() => onNavigate('listings')} className="relative">
            Post Surplus Now <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
