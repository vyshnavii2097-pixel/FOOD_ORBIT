import { type ReactNode } from 'react';

interface SectionHeadingProps {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  center?: boolean;
  light?: boolean;
}

export function SectionHeading({ eyebrow, title, subtitle, center, light }: SectionHeadingProps) {
  return (
    <div className={`${center ? 'text-center mx-auto' : ''} max-w-2xl`}>
      {eyebrow && (
        <div className={`inline-flex items-center gap-2 mb-4 ${center ? 'justify-center' : ''}`}>
          <span className="h-px w-8 bg-citrus-dark" />
          <span className={`text-xs font-bold uppercase tracking-widest ${light ? 'text-citrus' : 'text-forest-500'}`}>
            {eyebrow}
          </span>
          <span className="h-px w-8 bg-citrus-dark" />
        </div>
      )}
      <h2 className={`font-serif text-4xl md:text-5xl leading-tight ${light ? 'text-ivory' : 'text-forest-600'}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-lg leading-relaxed ${light ? 'text-sage' : 'text-forest-400'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
