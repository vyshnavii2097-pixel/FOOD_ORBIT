import { useState, useEffect } from 'react';
import { X, Leaf, Store, HeartHandshake, Bike, Mail, Lock, User, Loader2, AlertCircle } from 'lucide-react';
import { useAuth, type UserRole } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Button } from '@/components/ui/Button';

interface AuthModalProps {
  open: boolean;
  initialMode: 'login' | 'signup';
  initialRole?: UserRole;
  onClose: () => void;
}

const roleOptions: { id: UserRole; label: string; desc: string; icon: typeof Store }[] = [
  { id: 'donor', label: 'Donor', desc: 'Restaurants, hotels, stores', icon: Store },
  { id: 'ngo', label: 'NGO / Kitchen', desc: 'Receive surplus food', icon: HeartHandshake },
  { id: 'volunteer', label: 'Volunteer', desc: 'Pick up & deliver', icon: Bike },
];

export function AuthModal({ open, initialMode, initialRole, onClose }: AuthModalProps) {
  const { signUp, signIn } = useAuth();
  const { toast } = useToast();
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [role, setRole] = useState<UserRole>(initialRole || 'donor');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setMode(initialMode);
    setError(null);
  }, [initialMode, open]);

  useEffect(() => {
    if (initialRole) setRole(initialRole);
  }, [initialRole]);

  useEffect(() => {
    if (open) {
      setError(null);
      setPassword('');
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'signup') {
        if (!displayName.trim()) {
          setError('Please enter your name.');
          setLoading(false);
          return;
        }
        if (password.length < 6) {
          setError('Password must be at least 6 characters.');
          setLoading(false);
          return;
        }

        const { error: signUpError } = await signUp(email, password, displayName.trim(), role);
        if (signUpError) {
          setError(signUpError);
          setLoading(false);
          return;
        }
        toast(`Welcome to FOOD ORBIT, ${displayName.trim()}!`, 'success');
        onClose();
      } else {
        if (!email.trim() || !password) {
          setError('Please enter your email and password.');
          setLoading(false);
          return;
        }

        const { error: signInError } = await signIn(email, password);
        if (signInError) {
          setError(signInError);
          setLoading(false);
          return;
        }
        toast('Signed in successfully!', 'success');
        onClose();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-midnight/60 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-ivory rounded-3xl shadow-card animate-scale-in w-full max-w-md max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-lg hover:bg-forest-50 transition-colors z-10">
          <X className="w-5 h-5 text-forest-400" />
        </button>

        <div className="p-8">
          {/* Header */}
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-forest-600 flex items-center justify-center">
              <Leaf className="w-5 h-5 text-citrus" strokeWidth={2} />
            </div>
            <span className="font-bold text-forest-600 text-lg">FOOD ORBIT</span>
          </div>
          <h2 className="font-serif text-3xl text-forest-600 mb-1">
            {mode === 'signup' ? 'Join the Orbit' : 'Welcome Back'}
          </h2>
          <p className="text-sm text-forest-400 mb-6">
            {mode === 'signup' ? 'Create your account to start rescuing food.' : 'Sign in to your account.'}
          </p>

          {error && (
            <div className="flex items-start gap-2 bg-coral/10 border border-coral/30 rounded-xl p-3 mb-4 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-coral-dark flex-shrink-0 mt-0.5" />
              <p className="text-sm text-coral-dark">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <>
                {/* Role selection */}
                <div>
                  <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-2 block">
                    I am joining as
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {roleOptions.map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setRole(opt.id)}
                        className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all ${
                          role === opt.id
                            ? 'border-forest-600 bg-forest-50'
                            : 'border-forest-100 hover:border-forest-300'
                        }`}
                      >
                        <opt.icon className={`w-5 h-5 ${role === opt.id ? 'text-forest-600' : 'text-forest-400'}`} strokeWidth={1.5} />
                        <span className={`text-xs font-semibold ${role === opt.id ? 'text-forest-600' : 'text-forest-400'}`}>
                          {opt.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Display name */}
                <div>
                  <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">
                    {role === 'donor' ? 'Your Name' : role === 'ngo' ? 'Organization Name' : 'Your Name'}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-forest-300" />
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder={role === 'ngo' ? 'e.g. Hope Kitchen Collective' : 'e.g. Aarav Sharma'}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Email */}
            <div>
              <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-forest-300" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="text-xs font-semibold text-forest-500 uppercase tracking-wider mb-1.5 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-forest-300" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-forest-100 bg-white text-forest-600 text-sm focus:outline-none focus:border-forest-400 transition-colors"
                />
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {mode === 'signup' ? 'Creating account...' : 'Signing in...'}
                </>
              ) : (
                mode === 'signup' ? 'Create Account' : 'Sign In'
              )}
            </Button>
          </form>

          {/* Switch mode */}
          <div className="text-center mt-6">
            <button
              onClick={() => {
                setMode(mode === 'signup' ? 'login' : 'signup');
                setError(null);
              }}
              className="text-sm text-forest-400 hover:text-forest-600 transition-colors"
            >
              {mode === 'signup' ? 'Already have an account? ' : "Don't have an account? "}
              <span className="font-semibold text-forest-600">
                {mode === 'signup' ? 'Sign in' : 'Sign up'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
